export const subjectColors: Record<string, string> = {
  "All Subjects": "bg-gray-500/20 text-gray-400",
  "Mathematics": "bg-blue-500/20 text-blue-400",
  "Computer Science": "bg-violet-500/20 text-violet-400",
  "Physics": "bg-emerald-500/20 text-emerald-400",
  "Chemistry": "bg-amber-500/20 text-amber-400",
  "Biology": "bg-rose-500/20 text-rose-400",
  "English": "bg-cyan-500/20 text-cyan-400",
  "Custom": "bg-pink-500/20 text-pink-400",
};

export const subjects = Object.keys(subjectColors);
