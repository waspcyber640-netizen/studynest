import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAcHONVOj0tHKRrnC8toNq27_Xz0jU_l4U",
  authDomain: "studentconnect-2f040.firebaseapp.com",
  projectId: "studentconnect-2f040",
  storageBucket: "studentconnect-2f040.firebasestorage.app",
  messagingSenderId: "66573147028",
  appId: "1:66573147028:web:25a434988c62af8b2c4d81",
  measurementId: "G-XX7WC1JGHC",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app);
export const storage = getStorage(app);
export default app;
