import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const sections = [
  { title: "1. Account Rules", content: "You must be at least 13 years old to use StudyNest. You are responsible for maintaining the security of your account credentials. One account per person. Providing false information may result in termination." },
  { title: "2. Acceptable Use", content: "Use StudyNest for legitimate educational purposes. Do not upload malware, spam, or inappropriate content. Do not harass, impersonate, or exploit other users. Do not attempt to circumvent security measures." },
  { title: "3. Content Ownership", content: "You retain ownership of content you upload. By sharing assignments, you grant StudyNest a non-exclusive license to display and distribute the content within the platform. You may remove your content at any time." },
  { title: "4. Assignment Sharing Rules", content: "Only share materials you have the right to share. Do not upload copyrighted textbooks, exams with restricted distribution, or materials explicitly marked as non-sharable. You are responsible for ensuring compliance." },
  { title: "5. Termination", content: "We may suspend or terminate accounts that violate these terms. You may delete your account at any time. Upon termination, your uploaded content may be removed from the platform." },
  { title: "6. Disclaimers", content: "StudyNest is provided 'as is' without warranties. We do not guarantee the accuracy of user-uploaded content. We are not responsible for academic consequences resulting from the use of shared materials." },
  { title: "7. Governing Law", content: "These terms are governed by applicable laws. Any disputes shall be resolved through arbitration. By using StudyNest, you agree to these terms in their entirety." },
];

const TermsOfService = () => {
  usePageMeta({ title: "Terms of Service", description: "Read StudyNest's terms of service and usage policies." });
  return (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-3xl">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">Terms of Service</h1>
        <p className="text-sm text-muted-foreground mb-8">Last updated: March 8, 2026</p>
        <div className="space-y-6">
          {sections.map((s) => (
            <div key={s.title} className="glass rounded-xl p-5 sm:p-6">
              <h2 className="font-semibold text-base sm:text-lg mb-2">{s.title}</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  </PageTransition>
  );
};

export default TermsOfService;
