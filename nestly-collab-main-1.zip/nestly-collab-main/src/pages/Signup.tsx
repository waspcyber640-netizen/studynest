import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { BookOpen, Loader2, School, GraduationCap } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";
import { getRedirectResult } from "firebase/auth";
import { auth } from "@/firebase/config";
import PasswordStrength, { isPasswordStrong } from "@/components/PasswordStrength";

const schoolClasses = ["6", "7", "8", "9", "10", "11", "12"];
const universityYears = ["1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year", "Graduate", "PhD"];

const Signup = () => {
  usePageMeta({ title: "Sign Up", description: "Create your StudyNest account and start collaborating with classmates." });
  const { signUp, logInWithGoogle, user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [institutionType, setInstitutionType] = useState<"school" | "university" | "">("");
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [agreeCommunity, setAgreeCommunity] = useState(false);
  const [agreeData, setAgreeData] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    schoolName: "",
    className: "",
    university: "",
    department: "",
    year: "",
  });

  useEffect(() => {
    getRedirectResult(auth).then((result) => {
      if (result?.user) {
        toast.success("Welcome to StudyNest!");
        navigate("/dashboard");
      }
    }).catch(() => {});
  }, [navigate]);

  useEffect(() => {
    if (user && !loading) navigate("/dashboard");
  }, [user, loading, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.password) {
      toast.error("Please fill in all required fields.");
      return;
    }
    if (!isPasswordStrong(form.password)) {
      toast.error("Please use a strong password that meets all requirements.");
      return;
    }
    if (!institutionType) {
      toast.error("Please select School or University.");
      return;
    }
    if (institutionType === "school" && (!form.schoolName || !form.className)) {
      toast.error("Please fill in school name and class.");
      return;
    }
    if (institutionType === "university" && (!form.university || !form.department)) {
      toast.error("Please fill in university name and department.");
      return;
    }
    if (!agreeTerms || !agreeCommunity || !agreeData) {
      toast.error("Please accept all required consents to continue.");
      return;
    }

    setLoading(true);
    try {
      await signUp({
        email: form.email,
        password: form.password,
        name: form.name,
        institutionType,
        schoolName: form.schoolName,
        className: form.className,
        university: form.university,
        department: form.department,
        year: form.year,
      });
      toast.success("Account created! Welcome to StudyNest 🎉");
      navigate("/dashboard");
    } catch (err: any) {
      toast.error(err.message || "Failed to create account.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    setLoading(true);
    try {
      const result = await logInWithGoogle();
      if (result) {
        toast.success("Welcome to StudyNest!");
        navigate("/dashboard");
      }
    } catch (err: any) {
      toast.error(err.message || "Google sign-in failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageTransition>
      <div className="min-h-screen flex items-center justify-center px-4 pt-20 pb-8">
        <div className="glass rounded-2xl p-6 sm:p-8 w-full max-w-md">
          <div className="text-center mb-6">
            <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center mx-auto mb-4">
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">Create your account</h1>
            <p className="text-sm text-muted-foreground mt-1">Join StudyNest and start collaborating</p>
          </div>

          <form className="space-y-3" onSubmit={handleSubmit}>
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input id="name" placeholder="Alex Chen" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50" />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input id="email" type="email" placeholder="you@email.com" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50" />
            </div>
            <div>
              <Label htmlFor="password">Password *</Label>
              <Input id="password" type="password" placeholder="••••••••" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50" />
              <PasswordStrength password={form.password} />
            </div>

            {/* Institution Type Selector */}
            <div>
              <Label>I am a *</Label>
              <div className="grid grid-cols-2 gap-3 mt-1.5">
                <button
                  type="button"
                  onClick={() => setInstitutionType("school")}
                  className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                    institutionType === "school"
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border/50 bg-secondary/30 text-muted-foreground hover:border-border"
                  }`}
                >
                  <School className="h-6 w-6" />
                  <span className="text-sm font-medium">School Student</span>
                </button>
                <button
                  type="button"
                  onClick={() => setInstitutionType("university")}
                  className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                    institutionType === "university"
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border/50 bg-secondary/30 text-muted-foreground hover:border-border"
                  }`}
                >
                  <GraduationCap className="h-6 w-6" />
                  <span className="text-sm font-medium">University Student</span>
                </button>
              </div>
            </div>

            {/* School Fields */}
            {institutionType === "school" && (
              <div className="space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
                <div>
                  <Label htmlFor="schoolName">School Name *</Label>
                  <Input id="schoolName" placeholder="Delhi Public School" value={form.schoolName} onChange={(e) => setForm((f) => ({ ...f, schoolName: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50" />
                </div>
                <div>
                  <Label>Class *</Label>
                  <Select value={form.className} onValueChange={(v) => setForm((f) => ({ ...f, className: v }))}>
                    <SelectTrigger className="mt-1.5 bg-secondary/50 border-border/50">
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {schoolClasses.map((c) => (
                        <SelectItem key={c} value={c}>Class {c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* University Fields */}
            {institutionType === "university" && (
              <div className="space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
                <div>
                  <Label htmlFor="university">University Name *</Label>
                  <Input id="university" placeholder="MIT" value={form.university} onChange={(e) => setForm((f) => ({ ...f, university: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50" />
                </div>
                <div>
                  <Label htmlFor="department">Department *</Label>
                  <Input id="department" placeholder="Computer Science" value={form.department} onChange={(e) => setForm((f) => ({ ...f, department: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50" />
                </div>
                <div>
                  <Label>Year</Label>
                  <Select value={form.year} onValueChange={(v) => setForm((f) => ({ ...f, year: v }))}>
                    <SelectTrigger className="mt-1.5 bg-secondary/50 border-border/50">
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {universityYears.map((y) => (
                        <SelectItem key={y} value={y}>{y}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* Consent checkboxes */}
            <div className="space-y-3 pt-1">
              <div className="flex items-start gap-2.5">
                <Checkbox id="terms" checked={agreeTerms} onCheckedChange={(v) => setAgreeTerms(v === true)} className="mt-0.5" />
                <label htmlFor="terms" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                  I agree to the <Link to="/terms" className="text-primary hover:underline" target="_blank">Terms of Service</Link> and <Link to="/privacy" className="text-primary hover:underline" target="_blank">Privacy Policy</Link> *
                </label>
              </div>
              <div className="flex items-start gap-2.5">
                <Checkbox id="community" checked={agreeCommunity} onCheckedChange={(v) => setAgreeCommunity(v === true)} className="mt-0.5" />
                <label htmlFor="community" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                  I agree to follow the <Link to="/community-guidelines" className="text-primary hover:underline" target="_blank">Community Guidelines</Link> *
                </label>
              </div>
              <div className="flex items-start gap-2.5">
                <Checkbox id="data" checked={agreeData} onCheckedChange={(v) => setAgreeData(v === true)} className="mt-0.5" />
                <label htmlFor="data" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                  I consent to the collection and use of my data as described in the <Link to="/cookies" className="text-primary hover:underline" target="_blank">Cookie Policy</Link> *
                </label>
              </div>
            </div>

            <Button className="w-full" type="submit" disabled={loading || !agreeTerms || !agreeCommunity || !agreeData}>
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Sign Up
            </Button>

            <div className="relative my-3">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border/50" /></div>
              <div className="relative flex justify-center text-xs"><span className="bg-card px-2 text-muted-foreground">or</span></div>
            </div>

            <Button variant="outline" className="w-full" type="button" onClick={handleGoogle} disabled={loading}>
              <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
              Continue with Google
            </Button>
          </form>

          <p className="text-center text-sm text-muted-foreground mt-5">
            Already have an account? <Link to="/login" className="text-primary hover:underline">Log in</Link>
          </p>
        </div>
      </div>
    </PageTransition>
  );
};

export default Signup;
