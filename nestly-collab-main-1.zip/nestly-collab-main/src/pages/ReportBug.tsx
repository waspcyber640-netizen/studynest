import PageTransition from "@/components/PageTransition";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bug, Upload, CheckCircle } from "lucide-react";
import { useState, useRef } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { useAuth } from "@/context/AuthContext";
import usePageMeta from "@/hooks/usePageMeta";

const SUPPORT_EMAIL = "masspenmods@gmail.com";

const severities = ["Low — Cosmetic issue", "Medium — Feature partially broken", "High — Feature completely broken", "Critical — App unusable"];

const bugSchema = z.object({
  title: z.string().trim().min(1, "Bug title is required").max(200, "Title must be under 200 characters"),
  description: z.string().trim().min(10, "Description must be at least 10 characters").max(3000, "Description must be under 3000 characters"),
  steps: z.string().max(2000).optional(),
  severity: z.string().min(1, "Please select a severity level"),
});

const ReportBug = () => {
  usePageMeta({ title: "Report a Bug", description: "Report bugs and issues on StudyNest." });
  const { user, profile } = useAuth();
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ title: "", description: "", steps: "", severity: "" });
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const userEmail = user?.email || profile?.email || "";
  const userName = profile?.name || user?.displayName || "";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = bugSchema.safeParse(form);
    if (!result.success) {
      toast.error(result.error.errors[0].message);
      return;
    }

    const { title, description, steps, severity } = result.data;
    const body = [
      `Bug Title: ${title}`,
      `Severity: ${severity}`,
      `\nReported by: ${userName || "Anonymous"}`,
      `Email: ${userEmail || "Not logged in"}`,
      `\nDescription:\n${description}`,
      steps ? `\nSteps to Reproduce:\n${steps}` : "",
      screenshot ? `\n[Screenshot attached: ${screenshot.name}]` : "",
      `\n---\nSent from StudyNest Bug Reporter`,
    ].filter(Boolean).join("\n");

    const mailtoUrl = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`[StudyNest Bug] ${title}`)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoUrl, "_blank");
    setSent(true);
    toast.success("Opening your email client...");
  };

  if (sent) {
    return (
      <PageTransition>
        <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 flex items-center justify-center">
          <div className="glass rounded-2xl p-8 sm:p-12 text-center max-w-md w-full">
            <CheckCircle className="h-16 w-16 text-primary mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Bug Reported!</h2>
            <p className="text-sm text-muted-foreground mb-2">Your email client should have opened with the report pre-filled.</p>
            <p className="text-sm text-muted-foreground mb-6">
              If it didn't open, email us at{" "}
              <a href={`mailto:${SUPPORT_EMAIL}`} className="text-primary hover:underline">{SUPPORT_EMAIL}</a>
            </p>
            <Button onClick={() => { setSent(false); setForm({ title: "", description: "", steps: "", severity: "" }); setScreenshot(null); }}>Report Another Bug</Button>
          </div>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-lg">
          <div className="flex items-center gap-3 mb-2">
            <Bug className="h-7 w-7 text-primary" />
            <h1 className="text-2xl sm:text-3xl font-bold">Report a Bug</h1>
          </div>
          <p className="text-sm text-muted-foreground mb-8">Help us squash bugs and improve the experience.</p>

          <form className="glass rounded-xl p-5 sm:p-6 space-y-4" onSubmit={handleSubmit}>
            <div>
              <Label htmlFor="title">Bug Title *</Label>
              <Input id="title" placeholder="e.g. Upload button not responding" maxLength={200} value={form.title} onChange={(e) => setForm(f => ({ ...f, title: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50" />
            </div>
            <div>
              <Label htmlFor="desc">Description *</Label>
              <Textarea id="desc" placeholder="Describe the bug in detail..." maxLength={3000} value={form.description} onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50 min-h-[100px]" />
              <p className="text-xs text-muted-foreground mt-1 text-right">{form.description.length}/3000</p>
            </div>
            <div>
              <Label htmlFor="steps">Steps to Reproduce</Label>
              <Textarea id="steps" placeholder={"1. Go to...\n2. Click on...\n3. Observe..."} maxLength={2000} value={form.steps} onChange={(e) => setForm(f => ({ ...f, steps: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50 min-h-[80px]" />
            </div>
            <div>
              <Label>Severity *</Label>
              <Select value={form.severity} onValueChange={(v) => setForm(f => ({ ...f, severity: v }))}>
                <SelectTrigger className="mt-1.5 bg-secondary/50 border-border/50"><SelectValue placeholder="Select severity" /></SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {severities.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Screenshot (optional)</Label>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => setScreenshot(e.target.files?.[0] || null)} />
              <Button type="button" variant="outline" className="w-full mt-1.5" onClick={() => fileRef.current?.click()}>
                <Upload className="mr-2 h-4 w-4" />{screenshot ? screenshot.name : "Attach Screenshot"}
              </Button>
              <p className="text-xs text-muted-foreground mt-1">Please attach the screenshot manually to your email.</p>
            </div>
            <Button type="submit" className="w-full">
              <Bug className="mr-2 h-4 w-4" />
              Submit via Email
            </Button>
          </form>
        </div>
      </div>
    </PageTransition>
  );
};

export default ReportBug;
