import PageTransition from "@/components/PageTransition";
import { Cookie, Shield, BarChart3, Settings } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

const cookies = [
  { icon: Shield, title: "Essential Cookies", desc: "Required for authentication, session management, and core functionality. These cannot be disabled.", type: "Required" },
  { icon: BarChart3, title: "Analytics Cookies", desc: "Help us understand how you use StudyNest so we can improve the experience. Uses Firebase Analytics.", type: "Optional" },
  { icon: Settings, title: "Preference Cookies", desc: "Remember your settings like notification preferences, theme, and display options.", type: "Optional" },
];

const CookiePolicy = () => {
  usePageMeta({ title: "Cookie Policy", description: "Learn how StudyNest uses cookies to improve your experience." });
  return (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-3xl">
        <div className="flex items-center gap-3 mb-2">
          <Cookie className="h-7 w-7 text-primary" />
          <h1 className="text-2xl sm:text-3xl font-bold">Cookie Policy</h1>
        </div>
        <p className="text-sm text-muted-foreground mb-8">Last updated: March 8, 2026</p>

        <div className="glass rounded-xl p-5 sm:p-6 mb-6">
          <p className="text-sm text-muted-foreground leading-relaxed">
            Cookies are small text files stored on your device when you visit StudyNest. They help us provide a better experience by remembering your preferences and understanding usage patterns.
          </p>
        </div>

        <div className="space-y-4">
          {cookies.map((c) => (
            <div key={c.title} className="glass rounded-xl p-5 sm:p-6 flex items-start gap-4">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <c.icon className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-sm">{c.title}</h3>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${c.type === "Required" ? "bg-primary/20 text-primary" : "bg-secondary text-muted-foreground"}`}>{c.type}</span>
                </div>
                <p className="text-sm text-muted-foreground">{c.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="glass rounded-xl p-5 sm:p-6 mt-6">
          <h3 className="font-semibold mb-2">How to Opt Out</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            You can manage cookie preferences through the cookie consent banner or your browser settings. Disabling essential cookies may affect core functionality. You can clear cookies at any time through your browser.
          </p>
        </div>
      </div>
    </div>
  </PageTransition>
  );
};

export default CookiePolicy;
