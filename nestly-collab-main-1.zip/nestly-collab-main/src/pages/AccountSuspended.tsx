import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ShieldX, Mail } from "lucide-react";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const AccountSuspended = () => {
  usePageMeta({ title: "Account Suspended", description: "Your StudyNest account has been suspended.", noindex: true });
  return (
  <PageTransition>
    <div className="min-h-screen flex items-center justify-center px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-md">
        <div className="h-24 w-24 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto mb-6">
          <ShieldX className="h-12 w-12 text-destructive" />
        </div>
        <h1 className="text-2xl font-bold mb-2">Account Suspended</h1>
        <p className="text-sm text-muted-foreground mb-4">
          Your account has been suspended for violating our Community Guidelines.
        </p>
        <div className="glass rounded-xl p-4 mb-6 text-left">
          <p className="text-xs text-muted-foreground mb-1"><strong className="text-foreground">Reason:</strong></p>
          <p className="text-sm text-muted-foreground">Violation of community guidelines. Please review our terms for details.</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button asChild>
            <Link to="/contact"><Mail className="mr-2 h-4 w-4" />Contact Support</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link to="/community-guidelines">View Guidelines</Link>
          </Button>
        </div>
      </motion.div>
    </div>
  </PageTransition>
  );
};

export default AccountSuspended;
