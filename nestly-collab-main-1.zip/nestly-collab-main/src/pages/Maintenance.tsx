import { motion } from "framer-motion";
import { Wrench, Clock } from "lucide-react";
import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const Maintenance = () => {
  usePageMeta({ title: "Maintenance", description: "StudyNest is currently under maintenance.", noindex: true });
  return (
  <PageTransition>
    <div className="min-h-screen flex items-center justify-center px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-md">
        <motion.div
          animate={{ rotate: [0, 15, -15, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
          className="h-24 w-24 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-6"
        >
          <Wrench className="h-12 w-12 text-primary" />
        </motion.div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-3">StudyNest is Getting Smarter</h1>
        <p className="text-sm text-muted-foreground mb-6">
          We're performing scheduled maintenance to improve your experience. We'll be back shortly!
        </p>
        <div className="glass rounded-xl p-4 inline-flex items-center gap-2">
          <Clock className="h-4 w-4 text-primary" />
          <span className="text-sm text-muted-foreground">Estimated downtime: <span className="text-foreground font-medium">30 minutes</span></span>
        </div>
      </motion.div>
    </div>
  </PageTransition>
  );
};

export default Maintenance;
