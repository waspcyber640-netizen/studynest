import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { BookOpen, Users, Upload, MessageCircle, Sparkles, ArrowRight, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const features = [
  { icon: Upload, title: "Share Assignments", desc: "Upload and share notes, problem sets, and study materials with your peers." },
  { icon: Users, title: "Study Groups", desc: "Form or join groups organized by subject to collaborate in real-time." },
  { icon: MessageCircle, title: "Group Chat", desc: "Discuss problems, share solutions, and stay connected with your team." },
  { icon: Sparkles, title: "Smart Discovery", desc: "Find relevant materials and groups tailored to your courses." },
];

const benefits = [
  "Free to use forever",
  "No ads or spam",
  "Privacy-first approach",
  "Works on all devices",
];

const Landing = () => {
  usePageMeta({
    title: "StudyNest",
    description: "StudyNest is a free student collaboration platform. Share assignments, join study groups, and collaborate with classmates to ace your courses.",
    keywords: "study groups, student collaboration, share assignments, notes sharing, university, school, education platform",
    url: "https://studynest.app",
  });

  return (
    <PageTransition>
      <main className="min-h-screen">
        {/* Hero */}
        <section className="pt-20 sm:pt-28 lg:pt-36 pb-12 sm:pb-20 px-4" aria-label="Hero">
          <div className="container mx-auto text-center max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs sm:text-sm mb-6 sm:mb-8"
            >
              <BookOpen size={14} className="shrink-0" />
              <span>Student Collaboration Platform</span>
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight mb-4 sm:mb-6 px-2 leading-tight"
            >
              Learn Together,{" "}
              <span className="gradient-text">Grow Together</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-sm sm:text-base md:text-lg text-muted-foreground mb-6 sm:mb-8 max-w-2xl mx-auto px-2 leading-relaxed"
            >
              StudyNest brings students together to share resources, form study groups, and ace their courses collaboratively. Join thousands of students already learning smarter.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-center px-4"
            >
              <Button size="lg" asChild className="glow w-full sm:w-auto min-w-[160px]">
                <Link to="/signup">Get Started <ArrowRight className="ml-2 h-4 w-4" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="w-full sm:w-auto min-w-[160px]">
                <Link to="/login">Log In</Link>
              </Button>
            </motion.div>

            {/* Benefits list */}
            <motion.ul
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap justify-center gap-x-4 sm:gap-x-6 gap-y-2 mt-8 sm:mt-10 text-xs sm:text-sm text-muted-foreground"
              aria-label="Benefits"
            >
              {benefits.map((b) => (
                <li key={b} className="flex items-center gap-1.5">
                  <CheckCircle className="h-3.5 w-3.5 text-primary shrink-0" />
                  <span>{b}</span>
                </li>
              ))}
            </motion.ul>
          </div>
        </section>

        {/* Features */}
        <section className="py-12 sm:py-16 lg:py-20 px-4 bg-secondary/20" aria-labelledby="features-heading">
          <div className="container mx-auto max-w-6xl">
            <h2 id="features-heading" className="text-xl sm:text-2xl md:text-3xl font-bold text-center mb-3 sm:mb-4 px-2">
              Everything you need to <span className="gradient-text">study smarter</span>
            </h2>
            <p className="text-sm sm:text-base text-muted-foreground text-center mb-8 sm:mb-12 max-w-xl mx-auto">
              Powerful tools designed to help you collaborate, share, and succeed together.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {features.map((f, i) => (
                <motion.article
                  key={f.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.1 }}
                  className="glass-hover rounded-xl p-5 sm:p-6 text-center"
                >
                  <div className="h-11 w-11 sm:h-12 sm:w-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3 sm:mb-4">
                    <f.icon className="h-5 w-5 sm:h-6 sm:w-6 text-primary" aria-hidden="true" />
                  </div>
                  <h3 className="font-semibold text-sm sm:text-base mb-1.5 sm:mb-2">{f.title}</h3>
                  <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-12 sm:py-16 px-4" aria-label="Statistics">
          <div className="container mx-auto max-w-4xl">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
              {[
                { value: "10K+", label: "Students" },
                { value: "5K+", label: "Assignments" },
                { value: "500+", label: "Study Groups" },
                { value: "50+", label: "Universities" },
              ].map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="text-center p-4 sm:p-6"
                >
                  <p className="text-2xl sm:text-3xl md:text-4xl font-bold gradient-text">{stat.value}</p>
                  <p className="text-xs sm:text-sm text-muted-foreground mt-1">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-12 sm:py-16 lg:py-20 px-4" aria-label="Call to action">
          <div className="container mx-auto max-w-2xl text-center">
            <div className="glass rounded-2xl p-6 sm:p-10 lg:p-12 glow">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold mb-3 sm:mb-4">Ready to join the nest?</h2>
              <p className="text-xs sm:text-sm md:text-base text-muted-foreground mb-6 sm:mb-8 max-w-md mx-auto">
                Thousands of students are already collaborating. Don't get left behind.
              </p>
              <Button size="lg" asChild className="w-full sm:w-auto min-w-[180px]">
                <Link to="/signup">Create Free Account</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Landing Footer */}
        <footer className="border-t border-border/30 py-6 sm:py-8 px-4" role="contentinfo">
          <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center gap-3 text-xs sm:text-sm text-muted-foreground">
            <span className="gradient-text font-bold text-base">StudyNest</span>
            <span className="text-center">© 2026 StudyNest. Built for students, by students.</span>
          </div>
        </footer>
      </main>
    </PageTransition>
  );
};

export default Landing;
