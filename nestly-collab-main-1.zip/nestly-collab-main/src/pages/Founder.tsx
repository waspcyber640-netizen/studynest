import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";
import { BookOpen, Heart, Sparkles, Code, Globe, GraduationCap } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

const Founder = () => {
  usePageMeta({ title: "Meet the Founder", description: "Learn about the creator behind StudyNest." });
  return (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-3xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
          <h1 className="text-2xl sm:text-4xl font-bold mb-3">Meet the <span className="gradient-text">Founder</span></h1>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-2xl p-6 sm:p-10 text-center mb-8 glow"
        >
          <div className="h-24 w-24 sm:h-32 sm:w-32 rounded-full bg-gradient-to-br from-primary to-violet-500 flex items-center justify-center text-3xl sm:text-4xl font-bold text-white mx-auto mb-5 shadow-xl">
            MD
          </div>
          <h2 className="text-xl sm:text-2xl font-bold mb-1">Mahesh Dubey</h2>
          <p className="text-primary text-sm font-medium mb-4">Founder & Creator of StudyNest</p>
          <p className="text-sm text-muted-foreground leading-relaxed max-w-lg mx-auto">
            A passionate student and developer who believes in the power of collaborative learning. Mahesh built StudyNest to solve a problem he experienced firsthand — the difficulty of finding and sharing quality study materials with peers.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 gap-4 mb-8">
          {[
            { icon: BookOpen, title: "The Vision", desc: "Create a platform where every student can access shared knowledge and no one studies alone." },
            { icon: Code, title: "Built with Passion", desc: "StudyNest is crafted with modern technologies — React, Firebase, and a mobile-first approach." },
            { icon: GraduationCap, title: "Student-First", desc: "Every feature is designed from a student's perspective, solving real problems in real classrooms." },
            { icon: Globe, title: "For Everyone", desc: "From schools to universities, StudyNest is built to connect students across all institutions." },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.1 }}
              className="glass-hover rounded-xl p-5 flex items-start gap-4"
            >
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <item.icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-sm mb-1">{item.title}</h3>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="glass rounded-xl p-6 sm:p-8 text-center">
          <Heart className="h-8 w-8 text-primary mx-auto mb-3" />
          <p className="text-sm text-muted-foreground leading-relaxed max-w-md mx-auto italic">
            "Education is the most powerful weapon which you can use to change the world. StudyNest is my small contribution to making that weapon accessible to every student."
          </p>
          <p className="text-xs text-primary font-medium mt-3">— Mahesh Dubey</p>
        </div>
      </div>
    </div>
  </PageTransition>
  );
};

export default Founder;
