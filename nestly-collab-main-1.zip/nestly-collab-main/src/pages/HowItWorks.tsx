import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";
import { UserPlus, Upload, Users, ArrowRight } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

const steps = [
  { icon: UserPlus, title: "Sign Up", desc: "Create your free account in seconds. Tell us your school or university so we can match you with the right peers.", color: "from-primary to-violet-500" },
  { icon: Upload, title: "Share Assignments", desc: "Upload your notes, summaries, and study materials. Tag them by subject and they'll reach the right students automatically.", color: "from-violet-500 to-fuchsia-500" },
  { icon: Users, title: "Join Groups", desc: "Find or create study groups by subject. Collaborate in real-time chat, share files, and learn together.", color: "from-fuchsia-500 to-pink-500" },
];

const HowItWorks = () => {
  usePageMeta({ title: "How It Works", description: "Learn how to use StudyNest in three simple steps." });
  return (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-2xl sm:text-4xl font-bold mb-3">How <span className="gradient-text">StudyNest</span> Works</h1>
          <p className="text-muted-foreground text-sm sm:text-base">Get started in three simple steps.</p>
        </motion.div>

        <div className="space-y-6 sm:space-y-0 sm:grid sm:grid-cols-3 sm:gap-6 relative">
          {steps.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.15 }}
              className="relative"
            >
              <div className="glass-hover rounded-2xl p-6 sm:p-8 text-center h-full flex flex-col items-center">
                <div className={`h-16 w-16 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center mb-5 shadow-lg`}>
                  <step.icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-xs font-bold text-primary mb-2">STEP {i + 1}</div>
                <h3 className="text-lg font-bold mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
              </div>
              {i < steps.length - 1 && (
                <div className="hidden sm:flex absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
                  <ArrowRight className="h-6 w-6 text-primary/40" />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  </PageTransition>
  );
};

export default HowItWorks;
