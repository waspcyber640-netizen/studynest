import PageTransition from "@/components/PageTransition";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mail, Send, CheckCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import usePageMeta from "@/hooks/usePageMeta";

const SUPPORT_EMAIL = "masspenmods@gmail.com";

const subjectOptions = ["Bug Report", "Account Issue", "General Inquiry", "Partnership", "DMCA / Copyright", "Other"];

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name must be under 100 characters"),
  email: z.string().trim().email("Please enter a valid email"),
  subject: z.string().min(1, "Please select a subject"),
  message: z.string().trim().min(10, "Message must be at least 10 characters").max(2000, "Message must be under 2000 characters"),
});

const ContactUs = () => {
  usePageMeta({ title: "Contact Us", description: "Get in touch with the StudyNest team." });
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = contactSchema.safeParse(form);
    if (!result.success) {
      toast.error(result.error.errors[0].message);
      return;
    }

    const { name, email, subject, message } = result.data;
    const body = `Name: ${name}\nEmail: ${email}\nSubject: ${subject}\n\n${message}`;
    const mailtoUrl = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`[StudyNest Contact] ${subject}`)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoUrl, "_blank");
    setSent(true);
    toast.success("Opening your email client...");
  };

  if (sent) {
    return (
      <PageTransition>
        <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 flex items-center justify-center">
          <div className="glass rounded-2xl p-8 sm:p-12 text-center max-w-md w-full">
            <CheckCircle className="h-16 w-16 text-primary mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Message Ready!</h2>
            <p className="text-sm text-muted-foreground mb-2">Your email client should have opened with the message pre-filled.</p>
            <p className="text-sm text-muted-foreground mb-6">
              If it didn't open, email us directly at{" "}
              <a href={`mailto:${SUPPORT_EMAIL}`} className="text-primary hover:underline">{SUPPORT_EMAIL}</a>
            </p>
            <Button onClick={() => { setSent(false); setForm({ name: "", email: "", subject: "", message: "" }); }}>Send Another Message</Button>
          </div>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-lg">
          <div className="flex items-center gap-3 mb-2">
            <Mail className="h-7 w-7 text-primary" />
            <h1 className="text-2xl sm:text-3xl font-bold">Contact Us</h1>
          </div>
          <p className="text-sm text-muted-foreground mb-1">We'd love to hear from you.</p>
          <p className="text-xs text-muted-foreground mb-8">
            Or email us directly at <a href={`mailto:${SUPPORT_EMAIL}`} className="text-primary hover:underline">{SUPPORT_EMAIL}</a>
          </p>

          <form className="glass rounded-xl p-5 sm:p-6 space-y-4" onSubmit={handleSubmit}>
            <div>
              <Label htmlFor="name">Name *</Label>
              <Input id="name" placeholder="Your name" maxLength={100} value={form.name} onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50" />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input id="email" type="email" placeholder="you@email.com" maxLength={255} value={form.email} onChange={(e) => setForm(f => ({ ...f, email: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50" />
            </div>
            <div>
              <Label>Subject *</Label>
              <Select value={form.subject} onValueChange={(v) => setForm(f => ({ ...f, subject: v }))}>
                <SelectTrigger className="mt-1.5 bg-secondary/50 border-border/50"><SelectValue placeholder="Select a subject" /></SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {subjectOptions.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="message">Message *</Label>
              <Textarea id="message" placeholder="Tell us more..." maxLength={2000} value={form.message} onChange={(e) => setForm(f => ({ ...f, message: e.target.value }))} className="mt-1.5 bg-secondary/50 border-border/50 min-h-[120px]" />
              <p className="text-xs text-muted-foreground mt-1 text-right">{form.message.length}/2000</p>
            </div>
            <Button type="submit" className="w-full">
              <Send className="mr-2 h-4 w-4" />
              Send via Email
            </Button>
          </form>
        </div>
      </div>
    </PageTransition>
  );
};

export default ContactUs;
