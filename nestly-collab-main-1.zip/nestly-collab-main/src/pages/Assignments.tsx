import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { FileText, Download, Heart, Bookmark, Upload, Clock, Search, Loader2, Filter, Globe, Users } from "lucide-react";
import { subjects, subjectColors } from "@/data/mock";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import { SkeletonGrid } from "@/components/LoadingSkeletons";
import UploadModal from "@/components/UploadModal";
import CommentsSection from "@/components/CommentsSection";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { subscribeToAssignments, toggleLike, toggleSave, Assignment } from "@/services/assignmentService";
import { subscribeToGroups, Group } from "@/services/groupService";
import { getTelegramFileUrl, syncAssignmentFiles } from "@/services/telegramStorageService";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import usePageMeta from "@/hooks/usePageMeta";

const Assignments = () => {
  usePageMeta({ title: "Assignments", description: "Browse, share, and download student assignments on StudyNest." });
  const { user, profile } = useAuth();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAll, setShowAll] = useState(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [userGroups, setUserGroups] = useState<Group[]>([]);

  const handleDownload = async (fileUrl: string, assignmentId: string) => {
    // If it's a tg:// URL, resolve via Telegram API
    if (fileUrl.startsWith("tg://")) {
      setDownloadingId(assignmentId);
      try {
        const fileId = fileUrl.replace("tg://", "");
        const url = await getTelegramFileUrl(fileId);
        window.open(url, "_blank");
      } catch (err: any) {
        toast.error(err.message || "Download failed");
      } finally {
        setDownloadingId(null);
      }
    } else {
      // Legacy Firebase Storage URLs
      window.open(fileUrl, "_blank");
    }
  };

  useEffect(() => {
    const unsub = subscribeToAssignments((data) => {
      setAssignments(data);
      setLoading(false);
    });
    return unsub;
  }, []);

  // Auto-sync: remove assignments whose Telegram files were deleted
  useEffect(() => {
    syncAssignmentFiles().then(({ removed }) => {
      if (removed > 0) {
        toast.info(`Removed ${removed} assignment(s) with deleted files.`);
      }
    }).catch(() => {});
  }, []);

  const [allGroupIds, setAllGroupIds] = useState<string[]>([]);

  // Track all groups and user's groups
  useEffect(() => {
    if (!user) return;
    const unsub = subscribeToGroups((groups) => {
      setAllGroupIds(groups.map((g) => g.id));
      setUserGroups(groups.filter((g) => (g.memberIds || []).includes(user.uid)));
    });
    return unsub;
  }, [user]);

  // Filter: hide assignments whose group was deleted, and group files only visible to members
  const userGroupIds = userGroups.map((g) => g.id);
  const accessibleAssignments = assignments.filter((a) => {
    if (!a.groupId) return true; // Universal — no group, visible to all
    if (!allGroupIds.includes(a.groupId)) return false; // Group deleted — hide
    return userGroupIds.includes(a.groupId); // Group file — only if user is member
  });

  const relevantAssignments = accessibleAssignments.filter((a) => {
    if (showAll) return true;
    if (!profile?.institutionType) return true;
    if (profile.institutionType === "school") {
      return a.institutionType === "school" && a.className === profile.className;
    }
    if (profile.institutionType === "university") {
      return (
        a.institutionType === "university" &&
        a.department?.toLowerCase() === profile.department?.toLowerCase()
      );
    }
    return true;
  });

  const filtered = relevantAssignments
    .filter((a) => filter === "all" || a.subject === filter)
    .filter(
      (a) =>
        search === "" ||
        a.title.toLowerCase().includes(search.toLowerCase()) ||
        a.subject.toLowerCase().includes(search.toLowerCase()) ||
        a.uploaderName.toLowerCase().includes(search.toLowerCase())
    );

  const handleLike = (id: string) => {
    if (!user) return;
    toggleLike(id, user.uid);
  };

  const handleSave = (id: string) => {
    if (!user) return;
    toggleSave(id, user.uid);
  };

  const filterLabel = profile?.institutionType === "school"
    ? `Class ${profile.className}`
    : profile?.institutionType === "university"
    ? profile.department
    : null;

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 mb-6 sm:mb-8">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold">Assignment Feed</h1>
              <p className="text-muted-foreground mt-1 text-sm">
                {showAll
                  ? "Showing all assignments"
                  : filterLabel
                  ? `Showing ${filterLabel} assignments`
                  : "Browse and download shared study materials."}
              </p>
            </div>
            <Button onClick={() => setUploadOpen(true)} className="w-full sm:w-auto">
              <Upload className="mr-2 h-4 w-4" />Upload
            </Button>
          </div>

          

          {/* Search & Filter bar */}
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search assignments..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 bg-secondary/50 border-border/50" />
            </div>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-full sm:w-48 bg-secondary/50 border-border/50"><SelectValue placeholder="Filter by subject" /></SelectTrigger>
              <SelectContent className="bg-card border-border">
                <SelectItem value="all">All Subjects</SelectItem>
                {subjects.map((s) => (<SelectItem key={s} value={s}>{s}</SelectItem>))}
              </SelectContent>
            </Select>
          </div>

          {/* Scope toggle */}
          {filterLabel && (
            <div className="flex items-center gap-2 mb-4">
              <Button
                variant={showAll ? "outline" : "default"}
                size="sm"
                className="h-8 text-xs"
                onClick={() => setShowAll(false)}
              >
                <Filter className="mr-1 h-3 w-3" />My {filterLabel}
              </Button>
              <Button
                variant={showAll ? "default" : "outline"}
                size="sm"
                className="h-8 text-xs"
                onClick={() => setShowAll(true)}
              >
                All Notes
              </Button>
            </div>
          )}

          {loading && <SkeletonGrid count={6} />}

          {!loading && filtered.length === 0 && (
            <div className="text-center py-20">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-1">No assignments found</h3>
              <p className="text-sm text-muted-foreground mb-4">
                {!showAll && filterLabel
                  ? `No notes for ${filterLabel} yet. Try "All Notes" or upload the first one!`
                  : "Be the first to upload study materials!"}
              </p>
              <div className="flex gap-2 justify-center">
                {!showAll && filterLabel && (
                  <Button variant="outline" onClick={() => setShowAll(true)}>Show All Notes</Button>
                )}
                <Button onClick={() => setUploadOpen(true)}>
                  <Upload className="mr-2 h-4 w-4" />Upload Assignment
                </Button>
              </div>
            </div>
          )}

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((a, i) => {
              const isLiked = user ? (a.likedBy || []).includes(user.uid) : false;
              const isSaved = user ? (a.savedBy || []).includes(user.uid) : false;
              const timeAgo = a.createdAt ? formatDistanceToNow(a.createdAt.toDate(), { addSuffix: true }) : "just now";

              return (
                <motion.div key={a.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className="glass-hover rounded-xl p-4 sm:p-5 flex flex-col">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-sm leading-tight">{a.title}</p>
                      <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${subjectColors[a.subject] || "bg-primary/20 text-primary"}`}>{a.subject}</span>
                        <span className="text-xs text-muted-foreground uppercase">{a.fileType}</span>
                        {a.isPrivate && <span className="text-xs px-1.5 py-0.5 rounded bg-destructive/20 text-destructive">Private</span>}
                        {a.groupId ? (
                          <span className="text-xs px-1.5 py-0.5 rounded bg-accent/50 text-accent-foreground flex items-center gap-0.5">
                            <Users className="h-3 w-3" />{a.groupName || "Group"}
                          </span>
                        ) : (
                          <span className="text-xs px-1.5 py-0.5 rounded bg-primary/15 text-primary flex items-center gap-0.5">
                            <Globe className="h-3 w-3" />Universal
                          </span>
                        )}
                        {a.className && <span className="text-xs px-1.5 py-0.5 rounded bg-secondary/50 text-muted-foreground">Class {a.className}</span>}
                        {a.department && <span className="text-xs px-1.5 py-0.5 rounded bg-secondary/50 text-muted-foreground">{a.department}</span>}
                      </div>
                    </div>
                  </div>

                  {a.description && <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{a.description}</p>}

                  {a.tags && a.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {a.tags.map((tag) => (<span key={tag} className="text-[10px] px-1.5 py-0.5 rounded bg-secondary/50 text-muted-foreground">#{tag}</span>))}
                    </div>
                  )}

                  <div className="flex items-center gap-2 mt-auto pt-3 border-t border-border/30">
                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-[10px] font-semibold text-primary">{a.uploaderAvatar}</div>
                    <span className="text-xs text-muted-foreground flex-1 truncate">{a.uploaderName}</span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock size={10} />{timeAgo}</span>
                  </div>

                  <div className="flex items-center gap-1 sm:gap-1.5 mt-3 flex-wrap">
                    <Button variant="ghost" size="sm" className={`h-8 text-xs gap-1 px-2 ${isLiked ? "text-red-400" : ""}`} onClick={() => handleLike(a.id)}>
                      <Heart className={`h-3.5 w-3.5 ${isLiked ? "fill-current" : ""}`} />{a.likes || 0}
                    </Button>
                    <Button variant="ghost" size="sm" className={`h-8 text-xs px-2 ${isSaved ? "text-yellow-400" : ""}`} onClick={() => handleSave(a.id)}>
                      <Bookmark className={`h-3.5 w-3.5 ${isSaved ? "fill-current" : ""}`} />
                    </Button>
                    <CommentsSection assignmentId={a.id} commentCount={a.commentCount} />
                    <Button
                      variant="secondary"
                      size="sm"
                      className="h-8 text-xs ml-auto"
                      disabled={downloadingId === a.id}
                      onClick={() => handleDownload(a.fileUrl, a.id)}
                    >
                      {downloadingId === a.id ? (
                        <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                      ) : (
                        <Download className="mr-1 h-3 w-3" />
                      )}
                      Download
                    </Button>
                  </div>
                </motion.div>
              );
            })}
          </div>

          
        </div>
      </div>
      <UploadModal open={uploadOpen} onOpenChange={setUploadOpen} />
    </PageTransition>
  );
};

export default Assignments;
