import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";
import { Upload, Users, MessageCircle, Search, Bell, Shield, Globe, Smartphone, Zap, BookOpen, Heart, FileText } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

const features = [
  { icon: Upload, title: "Assignment Sharing", desc: "Upload PDF, DOCX, PPTX and more. Auto-tagged by subject and institution." },
  { icon: Users, title: "Study Groups", desc: "Create public or private groups organized by subject for focused collaboration." },
  { icon: MessageCircle, title: "Real-time Chat", desc: "Instant messaging within groups with file sharing and attachment support." },
  { icon: Search, title: "Smart Discovery", desc: "Find relevant materials filtered by your class, department, or institution." },
  { icon: Globe, title: "Universal & Group Files", desc: "Files tagged 'Universal' are visible to all; group files stay private to members." },
  { icon: Bell, title: "Smart Notifications", desc: "Get notified about new uploads, follows, and group activity. Customizable preferences." },
  { icon: Shield, title: "Safety & Moderation", desc: "Block users, report content, and community guidelines enforcement." },
  { icon: Heart, title: "Likes & Saves", desc: "Like and bookmark assignments for quick access later." },
  { icon: FileText, title: "Comments & Feedback", desc: "Leave comments on assignments to discuss and improve study materials." },
  { icon: Smartphone, title: "Mobile-First Design", desc: "Fully responsive interface that works beautifully on any device." },
  { icon: Zap, title: "Fast & Reliable", desc: "Built with modern tech for instant loading and real-time updates." },
  { icon: BookOpen, title: "Multi-Institution", desc: "Support for both schools and universities with targeted content delivery." },
];

const FeaturesPage = () => {
  usePageMeta({ title: "Features", description: "Explore all StudyNest features — assignment sharing, study groups, real-time chat, and more." });
  return (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-5xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-2xl sm:text-4xl font-bold mb-3">All <span className="gradient-text">Features</span></h1>
          <p className="text-muted-foreground text-sm sm:text-base max-w-xl mx-auto">Everything you need to study smarter, collaborate better, and ace your courses.</p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className="glass-hover rounded-xl p-5 sm:p-6"
            >
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                <f.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold text-sm mb-1.5">{f.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  </PageTransition>
  );
};

export default FeaturesPage;
