import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Users, Plus, Lock, Globe, MessageCircle, Loader2, LogOut } from "lucide-react";
import { subjectColors } from "@/data/mock";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import { SkeletonGrid } from "@/components/LoadingSkeletons";
import CreateGroupModal from "@/components/CreateGroupModal";
import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { subscribeToGroups, joinGroup, leaveGroup, Group } from "@/services/groupService";
import { toast } from "sonner";
import usePageMeta from "@/hooks/usePageMeta";

const Groups = () => {
  usePageMeta({ title: "Study Groups", description: "Join or create study groups to collaborate with classmates." });
  const { user } = useAuth();
  const [createOpen, setCreateOpen] = useState(false);
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = subscribeToGroups((data) => {
      setGroups(data);
      setLoading(false);
    });
    return unsub;
  }, []);

  const handleJoin = async (groupId: string) => {
    if (!user) return;
    try {
      await joinGroup(groupId, user.uid);
      toast.success("Joined group!");
    } catch (err: any) {
      toast.error(err.message || "Failed to join group.");
    }
  };

  const handleLeave = async (groupId: string) => {
    if (!user) return;
    try {
      await leaveGroup(groupId, user.uid);
      toast.success("Left group.");
    } catch (err: any) {
      toast.error(err.message || "Failed to leave group.");
    }
  };

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 mb-6 sm:mb-8">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold">Study Groups</h1>
              <p className="text-muted-foreground mt-1 text-sm">Find or create groups to study with peers.</p>
            </div>
            <Button onClick={() => setCreateOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />Create Group
            </Button>
          </div>

          {loading ? (
            <SkeletonGrid count={6} />
          ) : groups.length === 0 ? (
            <div className="text-center py-20">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-1">No groups yet</h3>
              <p className="text-sm text-muted-foreground mb-4">Create a study group to start collaborating!</p>
              <Button onClick={() => setCreateOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />Create Group
              </Button>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {groups.map((g, i) => {
                const isMember = user ? (g.memberIds || []).includes(user.uid) : false;
                const isCreator = user ? g.creatorId === user.uid : false;

                return (
                  <motion.div
                    key={g.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="glass-hover rounded-xl p-5 flex flex-col"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold">{g.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`text-xs px-2 py-0.5 rounded-full ${subjectColors[g.subject] || "bg-primary/20 text-primary"}`}>
                            {g.subject}
                          </span>
                          {g.isPublic ? (
                            <Globe size={12} className="text-muted-foreground" />
                          ) : (
                            <Lock size={12} className="text-muted-foreground" />
                          )}
                        </div>
                      </div>
                      {isMember && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-primary/20 text-primary">
                          Joined
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground flex-1 mb-4">
                      {g.description || "No description."}
                    </p>
                    <div className="flex items-center justify-between pt-3 border-t border-border/30">
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Users size={12} />{g.memberCount || 0} members
                      </span>
                      <div className="flex gap-2">
                        {isMember ? (
                          <>
                            <Button variant="ghost" size="sm" className="h-8 text-xs" asChild>
                              <Link to={`/groups/${g.id}/chat`}>
                                <MessageCircle className="mr-1 h-3 w-3" />Chat
                              </Link>
                            </Button>
                            {!isCreator && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 text-xs text-muted-foreground"
                                onClick={() => handleLeave(g.id)}
                              >
                                <LogOut className="mr-1 h-3 w-3" />Leave
                              </Button>
                            )}
                          </>
                        ) : (
                          <Button size="sm" className="h-8 text-xs" onClick={() => handleJoin(g.id)}>
                            Join
                          </Button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>
      <CreateGroupModal open={createOpen} onOpenChange={setCreateOpen} />
    </PageTransition>
  );
};

export default Groups;
