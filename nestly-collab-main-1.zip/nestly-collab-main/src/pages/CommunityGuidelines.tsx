import PageTransition from "@/components/PageTransition";
import { CheckCircle, XCircle, AlertTriangle, Flag } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

const allowed = [
  "Share your own notes, summaries, and study materials",
  "Form study groups and collaborate respectfully",
  "Give constructive feedback on shared materials",
  "Help peers with explanations and study tips",
  "Report content that violates these guidelines",
];

const notAllowed = [
  "Harassment, bullying, or intimidation of any kind",
  "Hate speech based on race, gender, religion, or orientation",
  "Plagiarism — passing off others' work as your own",
  "Sharing exam answers or facilitating academic dishonesty",
  "Spam, phishing, or malicious links",
  "Impersonating other students or faculty",
  "Uploading explicit, violent, or illegal content",
];

const consequences = [
  { level: "Warning", desc: "First minor violation — content removed, warning issued" },
  { level: "Temporary Suspension", desc: "Repeated violations — 7-30 day account suspension" },
  { level: "Permanent Ban", desc: "Severe violations — account permanently terminated" },
];

const CommunityGuidelines = () => {
  usePageMeta({ title: "Community Guidelines", description: "StudyNest community rules and guidelines for respectful collaboration." });
  return (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-3xl">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">Community Guidelines</h1>
        <p className="text-sm text-muted-foreground mb-8">Building a safe and productive learning environment.</p>

        <div className="glass rounded-xl p-5 sm:p-6 mb-6">
          <h2 className="font-semibold flex items-center gap-2 mb-3"><CheckCircle className="h-5 w-5 text-emerald-400" />What's Encouraged</h2>
          <ul className="space-y-2">
            {allowed.map((a) => (
              <li key={a} className="text-sm text-muted-foreground flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />{a}
              </li>
            ))}
          </ul>
        </div>

        <div className="glass rounded-xl p-5 sm:p-6 mb-6 border-destructive/30">
          <h2 className="font-semibold flex items-center gap-2 mb-3"><XCircle className="h-5 w-5 text-destructive" />Zero Tolerance — Not Allowed</h2>
          <ul className="space-y-2">
            {notAllowed.map((n) => (
              <li key={n} className="text-sm text-muted-foreground flex items-start gap-2">
                <XCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />{n}
              </li>
            ))}
          </ul>
        </div>

        <div className="glass rounded-xl p-5 sm:p-6 mb-6">
          <h2 className="font-semibold flex items-center gap-2 mb-3"><AlertTriangle className="h-5 w-5 text-yellow-400" />Consequences</h2>
          <div className="space-y-3">
            {consequences.map((c) => (
              <div key={c.level} className="flex items-start gap-3">
                <span className="text-xs font-semibold px-2 py-1 rounded bg-secondary text-foreground shrink-0">{c.level}</span>
                <p className="text-sm text-muted-foreground">{c.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-xl p-5 sm:p-6">
          <h2 className="font-semibold flex items-center gap-2 mb-2"><Flag className="h-5 w-5 text-primary" />How to Report</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Use the report button on any assignment, comment, group, or user profile. Reports are reviewed within 24 hours. You can also contact us at <a href="mailto:masspenmods@gmail.com" className="text-primary hover:underline">masspenmods@gmail.com</a>.
          </p>
        </div>
      </div>
    </div>
  </PageTransition>
  );
};

export default CommunityGuidelines;
