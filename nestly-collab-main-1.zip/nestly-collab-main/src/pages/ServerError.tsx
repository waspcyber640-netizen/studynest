import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const ServerError = () => {
  usePageMeta({ title: "Server Error", description: "Something went wrong on our end.", noindex: true });
  return (
  <PageTransition>
    <div className="min-h-screen flex items-center justify-center px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-md">
        <div className="h-24 w-24 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto mb-6">
          <AlertTriangle className="h-12 w-12 text-destructive" />
        </div>
        <h1 className="text-6xl font-extrabold text-destructive mb-4">500</h1>
        <h2 className="text-xl font-bold mb-2">Something Went Wrong</h2>
        <p className="text-sm text-muted-foreground mb-8">
          Something went wrong on our end. Our team has been notified and is working on a fix.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button onClick={() => window.location.reload()}>Try Again</Button>
          <Button variant="outline" onClick={() => window.location.href = "/dashboard"}>Back to Home</Button>
        </div>
      </motion.div>
    </div>
  </PageTransition>
  );
};

export default ServerError;
