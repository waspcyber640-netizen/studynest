import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const NotFound = () => {
  usePageMeta({ title: "Page Not Found", description: "This page doesn't exist on StudyNest." });
  return (
  <PageTransition>
    <div className="min-h-screen flex items-center justify-center px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-md">
        <div className="h-24 w-24 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
          <Search className="h-12 w-12 text-primary" />
        </div>
        <h1 className="text-6xl font-extrabold gradient-text mb-4">404</h1>
        <h2 className="text-xl font-bold mb-2">Page Not Found</h2>
        <p className="text-sm text-muted-foreground mb-8">
          Looks like this page got lost in the library. The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button asChild>
            <Link to="/dashboard">Back to Home</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link to="/help">Help Center</Link>
          </Button>
        </div>
      </motion.div>
    </div>
  </PageTransition>
  );
};

export default NotFound;
