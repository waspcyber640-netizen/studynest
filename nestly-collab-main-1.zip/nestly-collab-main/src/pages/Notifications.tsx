import { Bell, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import PageTransition from "@/components/PageTransition";
import { useAuth } from "@/context/AuthContext";
import { useState, useEffect } from "react";
import {
  subscribeToNotifications,
  markNotificationRead,
  AppNotification,
} from "@/services/groupService";
import { collection, query, where, orderBy, onSnapshot } from "firebase/firestore";
import { db } from "@/firebase/config";
import { formatDistanceToNow } from "date-fns";
import { Loader2 } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

const Notifications = () => {
  usePageMeta({ title: "Notifications", description: "View your StudyNest notifications.", noindex: true });
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { setLoading(false); return; }

    // Listen to user-specific notifications
    const unsub1 = subscribeToNotifications(user.uid, (data) => {
      setNotifications((prev) => {
        // Merge with broadcast notifications, deduplicate by id
        const ids = new Set(data.map((n) => n.id));
        const broadcasts = prev.filter((n) => !ids.has(n.id) && (n as any).userId === "__broadcast__");
        return [...data, ...broadcasts].sort((a, b) => {
          const aTime = a.createdAt?.toDate?.()?.getTime() || 0;
          const bTime = b.createdAt?.toDate?.()?.getTime() || 0;
          return bTime - aTime;
        });
      });
      setLoading(false);
    });

    // Listen to broadcast notifications (new uploads from others)
    const broadcastQuery = query(
      collection(db, "notifications"),
      where("userId", "==", "__broadcast__"),
      orderBy("createdAt", "desc")
    );
    const unsub2 = onSnapshot(broadcastQuery, (snap) => {
      const broadcasts = snap.docs
        .map((d) => ({ id: d.id, ...d.data() } as AppNotification))
        .filter((n) => (n as any).uploaderId !== user.uid); // Don't show own uploads

      setNotifications((prev) => {
        const userNotifs = prev.filter((n) => (n as any).userId !== "__broadcast__");
        return [...userNotifs, ...broadcasts].sort((a, b) => {
          const aTime = a.createdAt?.toDate?.()?.getTime() || 0;
          const bTime = b.createdAt?.toDate?.()?.getTime() || 0;
          return bTime - aTime;
        });
      });
    }, () => {});

    return () => { unsub1(); unsub2(); };
  }, [user]);

  const handleMarkRead = async (id: string) => {
    try { await markNotificationRead(id); } catch {}
  };

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-2xl">
          <h1 className="text-2xl sm:text-3xl font-bold mb-6">Notifications</h1>

          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : notifications.length === 0 ? (
            <div className="text-center py-20">
              <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-1">No notifications</h3>
              <p className="text-sm text-muted-foreground">You're all caught up!</p>
            </div>
          ) : (
            <div className="space-y-2">
              {notifications.map((n) => {
                const timeAgo = n.createdAt
                  ? formatDistanceToNow(n.createdAt.toDate(), { addSuffix: true })
                  : "just now";
                const notifType = (n as any).type || "";
                const icon = notifType === "follow" ? "👤" : notifType === "new_upload" ? "📄" : "🔔";

                return (
                  <div
                    key={n.id}
                    className={`glass-hover rounded-xl p-3 sm:p-4 flex items-start gap-2.5 sm:gap-3 ${!n.read ? "border-l-2 border-primary" : ""}`}
                  >
                    <span className="text-base sm:text-lg shrink-0">{icon}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium leading-tight">{n.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.body}</p>
                      <p className="text-[10px] text-muted-foreground mt-1">{timeAgo}</p>
                    </div>
                    {!n.read && (n as any).userId !== "__broadcast__" && (
                      <Button variant="ghost" size="sm" className="h-7 text-xs shrink-0 px-2" onClick={() => handleMarkRead(n.id)}>
                        <Check className="h-3 w-3 mr-1" />Read
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  );
};

export default Notifications;
