import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";
import { Sparkles, Bug, Wrench } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

const entries = [
  {
    version: "1.4.0", date: "March 8, 2026",
    items: [
      { type: "new", text: "File attachments in group chat via paperclip icon" },
      { type: "new", text: "Universal/Group source tags on assignments in feed" },
      { type: "new", text: "Group files only visible to members" },
      { type: "improved", text: "Mobile responsiveness across all pages" },
      { type: "fixed", text: "forwardRef console warning resolved" },
    ],
  },
  {
    version: "1.3.0", date: "March 5, 2026",
    items: [
      { type: "new", text: "Real-time group chat with auto-scrolling" },
      { type: "new", text: "Follow/unfollow system with notifications" },
      { type: "new", text: "Block users and report content" },
      { type: "improved", text: "Upload modal with drag & drop" },
    ],
  },
  {
    version: "1.2.0", date: "February 28, 2026",
    items: [
      { type: "new", text: "Study groups with subject tags" },
      { type: "new", text: "Comments on assignments" },
      { type: "new", text: "Like and save assignments" },
      { type: "fixed", text: "File download via Telegram API" },
    ],
  },
  {
    version: "1.1.0", date: "February 20, 2026",
    items: [
      { type: "new", text: "Assignment feed with subject filtering" },
      { type: "new", text: "Institution-based content targeting" },
      { type: "new", text: "Notification preferences" },
      { type: "improved", text: "Profile page with edit functionality" },
    ],
  },
  {
    version: "1.0.0", date: "February 10, 2026",
    items: [
      { type: "new", text: "Initial release of StudyNest" },
      { type: "new", text: "Firebase authentication with Google sign-in" },
      { type: "new", text: "Assignment upload via Telegram storage" },
      { type: "new", text: "User profiles with institution details" },
    ],
  },
];

const typeConfig = {
  new: { icon: Sparkles, label: "New", className: "bg-primary/15 text-primary" },
  improved: { icon: Wrench, label: "Improved", className: "bg-secondary text-muted-foreground" },
  fixed: { icon: Bug, label: "Fixed", className: "bg-destructive/15 text-destructive" },
};

const Changelog = () => {
  usePageMeta({ title: "Changelog", description: "See what's new, improved, and fixed in StudyNest." });
  return (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-3xl">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">Changelog</h1>
        <p className="text-sm text-muted-foreground mb-8">What's new, improved, and fixed in StudyNest.</p>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 sm:left-6 top-0 bottom-0 w-px bg-border/50" />

          <div className="space-y-8">
            {entries.map((entry, i) => (
              <motion.div
                key={entry.version}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                className="relative pl-10 sm:pl-14"
              >
                {/* Dot */}
                <div className="absolute left-2.5 sm:left-4.5 top-1 h-3 w-3 rounded-full bg-primary border-2 border-background" />

                <div className="glass rounded-xl p-5 sm:p-6">
                  <div className="flex items-center gap-3 mb-3 flex-wrap">
                    <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-primary/20 text-primary">v{entry.version}</span>
                    <span className="text-xs text-muted-foreground">{entry.date}</span>
                  </div>
                  <ul className="space-y-2">
                    {entry.items.map((item, j) => {
                      const config = typeConfig[item.type as keyof typeof typeConfig];
                      return (
                        <li key={j} className="flex items-start gap-2">
                          <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded shrink-0 mt-0.5 ${config.className}`}>{config.label}</span>
                          <span className="text-sm text-muted-foreground">{item.text}</span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </PageTransition>
  );
};

export default Changelog;
