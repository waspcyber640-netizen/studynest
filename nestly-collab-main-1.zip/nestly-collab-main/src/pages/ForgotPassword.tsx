import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BookOpen, Loader2, ArrowLeft } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useState } from "react";
import { toast } from "sonner";
import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const ForgotPassword = () => {
  usePageMeta({ title: "Forgot Password", description: "Reset your StudyNest account password." });
  const { resetPassword } = useAuth();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast.error("Please enter your email.");
      return;
    }
    setLoading(true);
    try {
      await resetPassword(email);
      setSent(true);
      toast.success("Password reset email sent!");
    } catch (err: any) {
      toast.error(err.message || "Failed to send reset email.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageTransition>
      <div className="min-h-screen flex items-center justify-center px-4 pt-20">
        <div className="glass rounded-2xl p-6 sm:p-8 w-full max-w-md">
          <div className="text-center mb-6">
            <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center mx-auto mb-4">
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">Reset Password</h1>
            <p className="text-sm text-muted-foreground mt-1">We'll send you a link to reset your password</p>
          </div>
          {sent ? (
            <div className="text-center space-y-4">
              <div className="h-16 w-16 rounded-full bg-success/20 flex items-center justify-center mx-auto">
                <span className="text-2xl">✉️</span>
              </div>
              <p className="text-sm text-muted-foreground">Check your inbox at <span className="text-foreground font-medium">{email}</span> for a password reset link.</p>
              <Button variant="outline" asChild className="w-full">
                <Link to="/login"><ArrowLeft className="mr-2 h-4 w-4" />Back to Login</Link>
              </Button>
            </div>
          ) : (
            <form className="space-y-4" onSubmit={handleSubmit}>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="you@university.edu" value={email} onChange={e => setEmail(e.target.value)} className="mt-1.5 bg-secondary/50 border-border/50" />
              </div>
              <Button className="w-full" type="submit" disabled={loading}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Send Reset Link
              </Button>
              <Button variant="ghost" asChild className="w-full">
                <Link to="/login"><ArrowLeft className="mr-2 h-4 w-4" />Back to Login</Link>
              </Button>
            </form>
          )}
        </div>
      </div>
    </PageTransition>
  );
};

export default ForgotPassword;
