import { useParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, ArrowLeft, Users, MessageCircle, Loader2, Paperclip } from "lucide-react";
import UploadModal from "@/components/UploadModal";
import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";
import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  getGroup,
  subscribeToMessages,
  sendMessage,
  joinGroup,
  Group,
  ChatMessage,
} from "@/services/groupService";
import { subjectColors } from "@/data/mock";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import usePageMeta from "@/hooks/usePageMeta";

const GroupChat = () => {
  usePageMeta({ title: "Group Chat", description: "Real-time group chat on StudyNest." });
  const { id } = useParams<{ id: string }>();
  const { user, profile } = useAuth();
  const [group, setGroup] = useState<Group | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!id) return;
    getGroup(id).then((g) => {
      setGroup(g);
      setLoading(false);
      // Auto-join if not a member
      if (g && user && !(g.memberIds || []).includes(user.uid)) {
        joinGroup(id, user.uid).then(() => {
          // Refresh group to get updated memberIds
          getGroup(id).then(setGroup);
        }).catch(() => {});
      }
    });
  }, [id, user]);

  useEffect(() => {
    if (!id) return;
    const unsub = subscribeToMessages(id, (msgs) => {
      setMessages(msgs);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
    });
    return unsub;
  }, [id]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !user || !id) return;
    setSending(true);
    try {
      const initials = (profile?.name || user.displayName || "U")
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2);

      await sendMessage(id, {
        userId: user.uid,
        userName: profile?.name || user.displayName || "Student",
        userAvatar: initials,
        text: text.trim(),
      });
      setText("");
    } catch (err: any) {
      toast.error("Failed to send message");
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <PageTransition>
      <div className="h-[100dvh] pt-16 flex flex-col overflow-hidden">
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar - desktop */}
          <div className="hidden lg:flex flex-col w-72 border-r border-border/30 glass">
            <div className="p-4 border-b border-border/30">
              <Link to="/groups" className="text-sm text-primary hover:underline flex items-center gap-1 mb-4">
                <ArrowLeft size={14} />Back to Groups
              </Link>
              <h2 className="font-bold text-lg">{group?.name || "Group"}</h2>
              {group?.subject && (
                <span className={`text-xs px-2 py-0.5 rounded-full ${subjectColors[group.subject] || "bg-primary/20 text-primary"}`}>
                  {group.subject}
                </span>
              )}
              <p className="text-sm text-muted-foreground mt-3">{group?.description || ""}</p>
            </div>
            <div className="p-4 flex-1 overflow-auto">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase mb-3 flex items-center gap-1">
                <Users size={12} />Members ({group?.memberCount || 0})
              </h3>
              <p className="text-xs text-muted-foreground">Member list loads from Firestore.</p>
            </div>
          </div>

          {/* Chat area */}
          <div className="flex-1 flex flex-col">
            {/* Mobile header */}
            <div className="lg:hidden border-b border-border/30 glass p-3 flex items-center gap-3">
              <Link to="/groups"><ArrowLeft size={18} /></Link>
              <div>
                <h2 className="font-semibold text-sm">{group?.name || "Group"}</h2>
                <span className="text-xs text-muted-foreground">{group?.memberCount || 0} members</span>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-auto p-4 space-y-4">
              {messages.length === 0 ? (
                <div className="flex-1 flex items-center justify-center h-full">
                  <div className="text-center">
                    <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-1">No messages yet</h3>
                    <p className="text-sm text-muted-foreground">Start the conversation!</p>
                  </div>
                </div>
              ) : (
                messages.map((msg, i) => {
                  const isMe = user ? msg.userId === user.uid : false;
                  const timeAgo = msg.createdAt
                    ? formatDistanceToNow(msg.createdAt.toDate(), { addSuffix: true })
                    : "just now";

                  return (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.02 }}
                      className={`flex gap-2.5 ${isMe ? "flex-row-reverse" : ""}`}
                    >
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-[10px] font-semibold text-primary shrink-0">
                        {msg.userAvatar || "U"}
                      </div>
                      <div className={`max-w-[70%] ${isMe ? "items-end" : ""}`}>
                        <div className={`flex items-center gap-2 mb-0.5 ${isMe ? "justify-end" : ""}`}>
                          {!isMe && <span className="text-xs font-medium">{msg.userName}</span>}
                          <span className="text-[10px] text-muted-foreground">{timeAgo}</span>
                        </div>
                        <div
                          className={`rounded-2xl px-4 py-2.5 text-sm ${
                            isMe
                              ? "bg-primary text-primary-foreground rounded-br-md"
                              : "glass rounded-bl-md"
                          }`}
                        >
                          {msg.text}
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              )}
              <div ref={bottomRef} />
            </div>

            {/* Message Input - always shown */}
            <div className="p-3 sm:p-4 border-t border-border/30 glass">
              <form className="flex gap-2 items-center" onSubmit={handleSend}>
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  className="shrink-0"
                  onClick={() => setUploadOpen(true)}
                >
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Input
                  placeholder="Type a message..."
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  className="bg-secondary/50 border-border/50 flex-1"
                  disabled={sending}
                />
                <Button size="icon" type="submit" disabled={sending || !text.trim()}>
                  {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <UploadModal
        open={uploadOpen}
        onOpenChange={setUploadOpen}
        groupId={id}
        groupName={group?.name}
      />
    </PageTransition>
  );
};

export default GroupChat;
