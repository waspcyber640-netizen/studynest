import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Heart, UserPlus } from "lucide-react";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const AccountDeleted = () => {
  usePageMeta({ title: "Account Deleted", description: "Your StudyNest account has been deleted.", noindex: true });
  return (
  <PageTransition>
    <div className="min-h-screen flex items-center justify-center px-4 pt-20">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-6 sm:p-10 text-center max-w-md w-full">
        <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
          <Heart className="h-10 w-10 text-primary" />
        </div>
        <h1 className="text-xl font-bold mb-2">Goodbye from StudyNest</h1>
        <p className="text-sm text-muted-foreground mb-6">
          Your account has been deleted. We're sorry to see you go. Your data has been removed from our servers.
        </p>
        <p className="text-xs text-muted-foreground mb-6">
          Changed your mind? You can always create a new account and rejoin the community.
        </p>
        <Button asChild className="w-full">
          <Link to="/signup"><UserPlus className="mr-2 h-4 w-4" />Sign Up Again</Link>
        </Button>
      </motion.div>
    </div>
  </PageTransition>
  );
};

export default AccountDeleted;
