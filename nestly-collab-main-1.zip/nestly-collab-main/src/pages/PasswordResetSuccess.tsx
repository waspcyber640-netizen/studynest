import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle, LogIn } from "lucide-react";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const PasswordResetSuccess = () => {
  usePageMeta({ title: "Password Reset Success", description: "Your password has been successfully reset.", noindex: true });
  return (
  <PageTransition>
    <div className="min-h-screen flex items-center justify-center px-4 pt-20">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-6 sm:p-10 text-center max-w-md w-full">
        <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
          <CheckCircle className="h-10 w-10 text-primary" />
        </div>
        <h1 className="text-xl font-bold mb-2">Password Reset Successful!</h1>
        <p className="text-sm text-muted-foreground mb-6">
          Your password has been updated. You can now log in with your new password.
        </p>
        <Button asChild className="w-full">
          <Link to="/login"><LogIn className="mr-2 h-4 w-4" />Log In</Link>
        </Button>
      </motion.div>
    </div>
  </PageTransition>
  );
};

export default PasswordResetSuccess;
