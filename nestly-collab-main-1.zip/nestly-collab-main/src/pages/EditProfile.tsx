import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Save, Loader2, School, GraduationCap, User, Camera } from "lucide-react";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import { useAuth } from "@/context/AuthContext";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "@/firebase/config";
import { toast } from "sonner";
import usePageMeta from "@/hooks/usePageMeta";

const EditProfile = () => {
  usePageMeta({ title: "Edit Profile", description: "Update your StudyNest profile information.", noindex: true });
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [loading, setSaving] = useState(false);

  // Form state
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [institutionType, setInstitutionType] = useState<"school" | "university">("school");
  const [schoolName, setSchoolName] = useState("");
  const [className, setClassName] = useState("");
  const [university, setUniversity] = useState("");
  const [department, setDepartment] = useState("");
  const [year, setYear] = useState("");
  const [skills, setSkills] = useState("");

  // Load existing profile data
  useEffect(() => {
    if (profile) {
      setName(profile.name || "");
      setBio(profile.bio || "");
      setInstitutionType(profile.institutionType || "school");
      setSchoolName(profile.schoolName || "");
      setClassName(profile.className || "");
      setUniversity(profile.university || "");
      setDepartment(profile.department || "");
      setYear(profile.year || "");
      setSkills((profile.skills || []).join(", "));
    }
  }, [profile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    // Basic validation
    if (!name.trim()) {
      toast.error("Name is required");
      return;
    }

    if (institutionType === "school" && (!schoolName.trim() || !className)) {
      toast.error("Please fill in all school details");
      return;
    }

    if (institutionType === "university" && (!university.trim() || !department.trim() || !year)) {
      toast.error("Please fill in all university details");
      return;
    }

    setSaving(true);
    try {
      const skillsArray = skills
        .split(",")
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

      await updateDoc(doc(db, "users", user.uid), {
        name: name.trim(),
        bio: bio.trim(),
        institutionType,
        schoolName: institutionType === "school" ? schoolName.trim() : "",
        className: institutionType === "school" ? className : "",
        university: institutionType === "university" ? university.trim() : "",
        department: institutionType === "university" ? department.trim() : "",
        year: institutionType === "university" ? year : "",
        skills: skillsArray,
      });

      toast.success("Profile updated!");
      navigate("/profile");
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  const initials = (name || profile?.name || "U")
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-lg">
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <Button variant="ghost" size="icon" onClick={() => navigate("/profile")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl sm:text-2xl font-bold">Edit Profile</h1>
          </div>

          <motion.form
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={handleSubmit}
            className="space-y-6"
          >
            {/* Avatar Section */}
            <div className="glass rounded-2xl p-6 text-center">
              <div className="relative inline-block">
                <div className="h-24 w-24 rounded-full bg-primary/20 flex items-center justify-center text-2xl font-bold text-primary mx-auto">
                  {initials}
                </div>
                <button
                  type="button"
                  className="absolute bottom-0 right-0 h-8 w-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground shadow-lg hover:bg-primary/90 transition-colors"
                >
                  <Camera className="h-4 w-4" />
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-3">Tap to change photo</p>
            </div>

            {/* Basic Info */}
            <div className="glass rounded-2xl p-5 space-y-4">
              <h2 className="font-semibold flex items-center gap-2">
                <User className="h-4 w-4 text-primary" />
                Basic Information
              </h2>

              <div className="space-y-2">
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your name"
                  className="bg-secondary/50 border-border/50"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Tell others about yourself..."
                  className="bg-secondary/50 border-border/50 min-h-[80px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="skills">Skills (comma separated)</Label>
                <Input
                  id="skills"
                  value={skills}
                  onChange={(e) => setSkills(e.target.value)}
                  placeholder="e.g. Math, Physics, Programming"
                  className="bg-secondary/50 border-border/50"
                />
              </div>
            </div>

            {/* Institution Info */}
            <div className="glass rounded-2xl p-5 space-y-4">
              <h2 className="font-semibold flex items-center gap-2">
                <GraduationCap className="h-4 w-4 text-primary" />
                Institution Details
              </h2>

              <div className="space-y-3">
                <Label>I am a...</Label>
                <RadioGroup
                  value={institutionType}
                  onValueChange={(v) => setInstitutionType(v as "school" | "university")}
                  className="grid grid-cols-2 gap-3"
                >
                  <Label
                    htmlFor="edit-school"
                    className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                      institutionType === "school"
                        ? "border-primary bg-primary/5"
                        : "border-border/50 hover:border-primary/50"
                    }`}
                  >
                    <RadioGroupItem value="school" id="edit-school" />
                    <div className="flex items-center gap-2">
                      <School className="h-4 w-4 text-primary" />
                      <span className="text-sm">School</span>
                    </div>
                  </Label>
                  <Label
                    htmlFor="edit-university"
                    className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                      institutionType === "university"
                        ? "border-primary bg-primary/5"
                        : "border-border/50 hover:border-primary/50"
                    }`}
                  >
                    <RadioGroupItem value="university" id="edit-university" />
                    <div className="flex items-center gap-2">
                      <GraduationCap className="h-4 w-4 text-primary" />
                      <span className="text-sm">University</span>
                    </div>
                  </Label>
                </RadioGroup>
              </div>

              {/* School Fields */}
              {institutionType === "school" && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="space-y-4 pt-2"
                >
                  <div className="space-y-2">
                    <Label htmlFor="schoolName">School Name *</Label>
                    <Input
                      id="schoolName"
                      value={schoolName}
                      onChange={(e) => setSchoolName(e.target.value)}
                      placeholder="Enter your school name"
                      className="bg-secondary/50 border-border/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="className">Class *</Label>
                    <Select value={className} onValueChange={setClassName}>
                      <SelectTrigger className="bg-secondary/50 border-border/50">
                        <SelectValue placeholder="Select your class" />
                      </SelectTrigger>
                      <SelectContent>
                        {["9", "10", "11", "12"].map((c) => (
                          <SelectItem key={c} value={c}>
                            Class {c}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </motion.div>
              )}

              {/* University Fields */}
              {institutionType === "university" && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="space-y-4 pt-2"
                >
                  <div className="space-y-2">
                    <Label htmlFor="university">University Name *</Label>
                    <Input
                      id="university"
                      value={university}
                      onChange={(e) => setUniversity(e.target.value)}
                      placeholder="Enter your university name"
                      className="bg-secondary/50 border-border/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="department">Department *</Label>
                    <Input
                      id="department"
                      value={department}
                      onChange={(e) => setDepartment(e.target.value)}
                      placeholder="e.g. Computer Science"
                      className="bg-secondary/50 border-border/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="year">Year *</Label>
                    <Select value={year} onValueChange={setYear}>
                      <SelectTrigger className="bg-secondary/50 border-border/50">
                        <SelectValue placeholder="Select your year" />
                      </SelectTrigger>
                      <SelectContent>
                        {["1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year", "Postgraduate"].map((y) => (
                          <SelectItem key={y} value={y}>
                            {y}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Submit Button */}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </>
              )}
            </Button>
          </motion.form>
        </div>
      </div>
    </PageTransition>
  );
};

export default EditProfile;
