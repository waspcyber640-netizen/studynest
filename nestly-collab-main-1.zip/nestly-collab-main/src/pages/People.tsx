import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import FollowButton from "@/components/FollowButton";
import { getSuggestedPeople, PublicProfile, subscribeToFollowers, subscribeToFollowing } from "@/services/connectionService";
import { subscribeToBlockedUsers, blockUser, unblockUser } from "@/services/safetyService";
import { subscribeToNotificationPreferences, updateNotificationPreferences, NotificationPreferences, defaultPreferences } from "@/services/notificationPreferencesService";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Users, UserPlus, ShieldAlert, Bell, Ban, Loader2 } from "lucide-react";
import { toast } from "sonner";
import usePageMeta from "@/hooks/usePageMeta";

const PeoplePage = () => {
  usePageMeta({ title: "People", description: "Discover and connect with fellow students on StudyNest." });
  const { user, profile } = useAuth();
  const [tab, setTab] = useState<"discover" | "followers" | "following" | "blocked" | "settings">("discover");
  const [suggestions, setSuggestions] = useState<PublicProfile[]>([]);
  const [followers, setFollowers] = useState<string[]>([]);
  const [following, setFollowing] = useState<string[]>([]);
  const [blockedUsers, setBlockedUsers] = useState<string[]>([]);
  const [prefs, setPrefs] = useState<NotificationPreferences>(defaultPreferences);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || !profile) return;
    setLoading(true);
    getSuggestedPeople(
      user.uid,
      profile.institutionType,
      profile.className,
      profile.department
    ).then((data) => {
      setSuggestions(data);
      setLoading(false);
    });
  }, [user, profile]);

  useEffect(() => {
    if (!user) return;
    const unsubs = [
      subscribeToFollowers(user.uid, (c) => setFollowers(c.map((f) => f.followerId))),
      subscribeToFollowing(user.uid, (c) => setFollowing(c.map((f) => f.followingId))),
      subscribeToBlockedUsers(user.uid, setBlockedUsers),
      subscribeToNotificationPreferences(user.uid, setPrefs),
    ];
    return () => unsubs.forEach((u) => u());
  }, [user]);

  const handleBlock = async (userId: string) => {
    if (!user) return;
    try {
      await blockUser(user.uid, userId);
      toast.success("User blocked");
    } catch {
      toast.error("Failed to block");
    }
  };

  const handleUnblock = async (userId: string) => {
    if (!user) return;
    try {
      await unblockUser(user.uid, userId);
      toast.success("User unblocked");
    } catch {
      toast.error("Failed to unblock");
    }
  };

  const handleTogglePref = async (key: keyof Omit<NotificationPreferences, "mutedUsers" | "mutedGroups">) => {
    if (!user) return;
    const newVal = !prefs[key];
    setPrefs((p) => ({ ...p, [key]: newVal }));
    await updateNotificationPreferences(user.uid, { [key]: newVal });
  };

  const tabs = [
    { id: "discover" as const, label: "Discover", icon: UserPlus },
    { id: "followers" as const, label: `Followers`, count: followers.length, icon: Users },
    { id: "following" as const, label: `Following`, count: following.length, icon: Users },
    { id: "blocked" as const, label: "Blocked", icon: Ban },
    { id: "settings" as const, label: "Settings", icon: Bell },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-4xl">
          <h1 className="text-2xl sm:text-3xl font-bold mb-6">People & Settings</h1>

          {/* Tabs */}
          <div className="flex gap-1.5 sm:gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide -mx-3 px-3 sm:mx-0 sm:px-0">
            {tabs.map((t) => (
              <Button
                key={t.id}
                variant={tab === t.id ? "default" : "outline"}
                size="sm"
                className="text-[11px] sm:text-xs shrink-0 h-8 px-2.5 sm:px-3"
                onClick={() => setTab(t.id)}
              >
                <t.icon className="h-3 w-3 mr-1" />
                {t.label}
                {"count" in t && <span className="ml-1 text-[10px] opacity-70">{(t as any).count}</span>}
              </Button>
            ))}
          </div>

          {/* Discover */}
          {tab === "discover" && (
            <>
              {loading ? (
                <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
              ) : suggestions.length === 0 ? (
                <div className="text-center py-20">
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-1">No suggestions yet</h3>
                  <p className="text-sm text-muted-foreground">We'll suggest people from your class or department.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {suggestions.map((p, i) => {
                    const initials = p.name ? p.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2) : "?";
                    return (
                      <motion.div
                        key={p.uid}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.04 }}
                        className="glass-hover rounded-xl p-4 flex items-center gap-3"
                      >
                        <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary shrink-0">
                          {initials}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium">{p.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {p.institutionType === "school" ? `${p.schoolName} · Class ${p.className}` : `${p.university} · ${p.department}`}
                          </p>
                        </div>
                        <div className="flex gap-1 sm:gap-1.5 shrink-0">
                          <FollowButton targetUserId={p.uid} targetUserName={p.name} />
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-destructive" onClick={() => handleBlock(p.uid)}>
                            <ShieldAlert className="h-3 w-3" />
                          </Button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* Followers / Following (simple list with IDs — in production you'd resolve to profiles) */}
          {(tab === "followers" || tab === "following") && (
            <div className="space-y-2">
              {(tab === "followers" ? followers : following).length === 0 ? (
                <div className="text-center py-20">
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-1">No {tab} yet</h3>
                </div>
              ) : (
                (tab === "followers" ? followers : following).map((uid) => (
                  <div key={uid} className="glass-hover rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary">U</div>
                      <span className="text-sm text-muted-foreground truncate">{uid.slice(0, 12)}...</span>
                    </div>
                    <FollowButton targetUserId={uid} />
                  </div>
                ))
              )}
            </div>
          )}

          {/* Blocked */}
          {tab === "blocked" && (
            <div className="space-y-2">
              {blockedUsers.length === 0 ? (
                <div className="text-center py-20">
                  <Ban className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-1">No blocked users</h3>
                </div>
              ) : (
                blockedUsers.map((uid) => (
                  <div key={uid} className="glass-hover rounded-xl p-4 flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{uid.slice(0, 12)}...</span>
                    <Button variant="outline" size="sm" className="text-xs" onClick={() => handleUnblock(uid)}>Unblock</Button>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Notification Settings */}
          {tab === "settings" && (
            <div className="glass rounded-xl p-6 space-y-5">
              <h3 className="font-semibold flex items-center gap-2"><Bell className="h-4 w-4 text-primary" />Notification Preferences</h3>
              {([
                { key: "likes" as const, label: "Likes on your assignments" },
                { key: "comments" as const, label: "Comments on your assignments" },
                { key: "follows" as const, label: "New followers" },
                { key: "sessions" as const, label: "Study session reminders" },
                { key: "groupMessages" as const, label: "Group chat messages" },
              ]).map((item) => (
                <div key={item.key} className="flex items-center justify-between">
                  <Label className="text-sm">{item.label}</Label>
                  <Switch checked={prefs[item.key]} onCheckedChange={() => handleTogglePref(item.key)} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  );
};

export default PeoplePage;
