import PageTransition from "@/components/PageTransition";
import usePageMeta from "@/hooks/usePageMeta";

const sections = [
  {
    title: "1. Information We Collect",
    content: `We collect information you provide directly: name, email, institution details, profile information, and uploaded study materials. We also collect usage data such as pages visited, features used, and device information through Firebase Analytics.`,
  },
  {
    title: "2. How We Use Your Data",
    content: `Your data is used to provide and improve StudyNest services, personalize your experience, match you with relevant study groups and materials, send notifications, and ensure platform safety.`,
  },
  {
    title: "3. Data Storage & Security",
    content: `Your data is stored securely using Firebase (Google Cloud Platform) infrastructure with encryption at rest and in transit. We implement industry-standard security measures to protect your information.`,
  },
  {
    title: "4. Third-Party Services",
    content: `We use Firebase for authentication, database, and storage; Telegram Bot API for file storage; and standard analytics tools. These services have their own privacy policies.`,
  },
  {
    title: "5. Student Data Protection",
    content: `We are committed to protecting student data. We do not sell personal information. We limit data collection to what is necessary for the service. We provide data export and deletion options upon request.`,
  },
  {
    title: "6. COPPA & FERPA Compliance",
    content: `StudyNest is designed for students aged 13 and above. We do not knowingly collect data from children under 13. We comply with FERPA by ensuring educational records are protected and only shared with proper authorization.`,
  },
  {
    title: "7. Your Rights",
    content: `You have the right to access, correct, or delete your personal data. You can export your data at any time. You may opt out of non-essential communications. Contact us to exercise these rights.`,
  },
  {
    title: "8. Contact Us",
    content: `For privacy-related questions, contact us at masspenmods@gmail.com or through our Contact Us page.`,
  },
];

const PrivacyPolicy = () => (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-3xl">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">Privacy Policy</h1>
        <p className="text-sm text-muted-foreground mb-8">Last updated: March 8, 2026</p>
        <div className="space-y-6">
          {sections.map((s) => (
            <div key={s.title} className="glass rounded-xl p-5 sm:p-6">
              <h2 className="font-semibold text-base sm:text-lg mb-2">{s.title}</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  </PageTransition>
);

export default PrivacyPolicy;
