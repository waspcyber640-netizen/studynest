import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GraduationCap, School, ArrowRight, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import { useAuth } from "@/context/AuthContext";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "@/firebase/config";
import { toast } from "sonner";
import usePageMeta from "@/hooks/usePageMeta";

const CompleteProfile = () => {
  usePageMeta({ title: "Complete Profile", description: "Complete your StudyNest profile to get started.", noindex: true });
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [loading, setLoading] = useState(false);

  const [institutionType, setInstitutionType] = useState<"school" | "university">("school");
  const [schoolName, setSchoolName] = useState("");
  const [className, setClassName] = useState("");
  const [university, setUniversity] = useState("");
  const [department, setDepartment] = useState("");
  const [year, setYear] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    // Validation
    if (institutionType === "school" && (!schoolName.trim() || !className)) {
      toast.error("Please fill in all school details");
      return;
    }
    if (institutionType === "university" && (!university.trim() || !department.trim() || !year)) {
      toast.error("Please fill in all university details");
      return;
    }

    setLoading(true);
    try {
      const userRef = doc(db, "users", user.uid);
      await updateDoc(userRef, {
        institutionType,
        schoolName: institutionType === "school" ? schoolName.trim() : "",
        className: institutionType === "school" ? className : "",
        university: institutionType === "university" ? university.trim() : "",
        department: institutionType === "university" ? department.trim() : "",
        year: institutionType === "university" ? year : "",
      });
      toast.success("Profile completed!");
      navigate("/onboarding");
    } catch (err) {
      console.error(err);
      toast.error("Failed to save profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageTransition>
      <div className="min-h-screen flex items-center justify-center px-4 pt-20 pb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-6 sm:p-8 w-full max-w-md"
        >
          <div className="text-center mb-6">
            <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <GraduationCap className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold mb-2">Complete Your Profile</h1>
            <p className="text-sm text-muted-foreground">
              Tell us about your institution to personalize your experience
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Institution Type */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">I am a...</Label>
              <RadioGroup
                value={institutionType}
                onValueChange={(v) => setInstitutionType(v as "school" | "university")}
                className="grid grid-cols-2 gap-3"
              >
                <Label
                  htmlFor="school"
                  className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                    institutionType === "school"
                      ? "border-primary bg-primary/5"
                      : "border-border/50 hover:border-primary/50"
                  }`}
                >
                  <RadioGroupItem value="school" id="school" />
                  <div className="flex items-center gap-2">
                    <School className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">School Student</span>
                  </div>
                </Label>
                <Label
                  htmlFor="university"
                  className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                    institutionType === "university"
                      ? "border-primary bg-primary/5"
                      : "border-border/50 hover:border-primary/50"
                  }`}
                >
                  <RadioGroupItem value="university" id="university" />
                  <div className="flex items-center gap-2">
                    <GraduationCap className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">University Student</span>
                  </div>
                </Label>
              </RadioGroup>
            </div>

            {/* School Fields */}
            {institutionType === "school" && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Label htmlFor="schoolName">School Name</Label>
                  <Input
                    id="schoolName"
                    placeholder="Enter your school name"
                    value={schoolName}
                    onChange={(e) => setSchoolName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="className">Class</Label>
                  <Select value={className} onValueChange={setClassName}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your class" />
                    </SelectTrigger>
                    <SelectContent>
                      {["9", "10", "11", "12"].map((c) => (
                        <SelectItem key={c} value={c}>
                          Class {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </motion.div>
            )}

            {/* University Fields */}
            {institutionType === "university" && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Label htmlFor="university">University Name</Label>
                  <Input
                    id="university"
                    placeholder="Enter your university name"
                    value={university}
                    onChange={(e) => setUniversity(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Input
                    id="department"
                    placeholder="e.g. Computer Science"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="year">Year</Label>
                  <Select value={year} onValueChange={setYear}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your year" />
                    </SelectTrigger>
                    <SelectContent>
                      {["1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year", "Postgraduate"].map((y) => (
                        <SelectItem key={y} value={y}>
                          {y}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </motion.div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  Continue <ArrowRight className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          </form>
        </motion.div>
      </div>
    </PageTransition>
  );
};

export default CompleteProfile;
