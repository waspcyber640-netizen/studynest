import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import {
  Upload,
  Download,
  FileText,
  Loader2,
  AlertCircle,
  Clock,
  RefreshCw,
  CheckCircle2,
  WifiOff,
  Timer,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import {
  uploadPdfToTelegram,
  getTelegramFileUrl,
  subscribeToTelegramFiles,
  TelegramFile,
} from "@/services/telegramStorageService";
import { useTelegramAutoSync } from "@/hooks/useTelegramAutoSync";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import PageTransition from "@/components/PageTransition";
import { motion, AnimatePresence } from "framer-motion";
import usePageMeta from "@/hooks/usePageMeta";

const SyncStatusBadge = ({
  isSyncing,
  status,
  formatLastSynced,
  formatNextSync,
  lastResult,
}: {
  isSyncing: boolean;
  status: string;
  formatLastSynced: () => string | null;
  formatNextSync: () => string;
  lastResult: { removed: number; checked: number } | null;
}) => {
  const lastSynced = formatLastSynced();

  return (
    <div className="flex items-center gap-2 text-xs text-muted-foreground">
      <AnimatePresence mode="wait">
        {isSyncing ? (
          <motion.span
            key="syncing"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="flex items-center gap-1.5 text-primary"
          >
            <Loader2 className="h-3 w-3 animate-spin" />
            Syncing...
          </motion.span>
        ) : status === "error" ? (
          <motion.span
            key="error"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="flex items-center gap-1.5 text-destructive"
          >
            <WifiOff className="h-3 w-3" />
            Sync failed
          </motion.span>
        ) : status === "success" ? (
          <motion.span
            key="success"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="flex items-center gap-1.5 text-green-500"
          >
            <CheckCircle2 className="h-3 w-3" />
            {lastSynced ? `Synced ${lastSynced}` : "Synced"}
            {lastResult && ` · ${lastResult.checked} checked`}
          </motion.span>
        ) : (
          <motion.span
            key="idle"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex items-center gap-1.5"
          >
            <Timer className="h-3 w-3" />
            Next sync in {formatNextSync()}
          </motion.span>
        )}
      </AnimatePresence>
    </div>
  );
};

const TelegramFiles = () => {
  usePageMeta({
    title: "PDF Storage",
    description: "Upload and download PDF files via Telegram on StudyNest.",
    noindex: true,
  });

  const { user, profile } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<TelegramFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [downloading, setDownloading] = useState<string | null>(null);

  const {
    status,
    isSyncing,
    lastResult,
    triggerSync,
    formatNextSync,
    formatLastSynced,
  } = useTelegramAutoSync(true);

  useEffect(() => {
    const unsub = subscribeToTelegramFiles((data) => {
      setFiles(data);
      setLoading(false);
    });
    return unsub;
  }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (!file.name.toLowerCase().endsWith(".pdf")) {
      toast.error("Only PDF files are allowed.");
      return;
    }

    setUploading(true);
    try {
      const name = profile?.name || user.displayName || "Student";
      await uploadPdfToTelegram(file, user.uid, name);
      toast.success("PDF uploaded successfully! 🎉");
      triggerSync();
    } catch (err: any) {
      toast.error(err.message || "Upload failed");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const handleDownload = async (fileId: string, fileName: string) => {
    setDownloading(fileId);
    try {
      const url = await getTelegramFileUrl(fileId);
      window.open(url, "_blank");
    } catch (err: any) {
      toast.error(err.message || "Download failed");
    } finally {
      setDownloading(null);
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-4xl">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-6 sm:mb-8">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold">PDF Storage</h1>
              <p className="text-muted-foreground mt-1 text-sm">
                Upload and download PDF files via Telegram
              </p>
              <div className="mt-2">
                <SyncStatusBadge
                  isSyncing={isSyncing}
                  status={status}
                  formatLastSynced={formatLastSynced}
                  formatNextSync={formatNextSync}
                  lastResult={lastResult}
                />
              </div>
            </div>
            <div className="flex gap-2">
              <input
                ref={fileRef}
                type="file"
                accept=".pdf"
                className="hidden"
                onChange={handleUpload}
              />
              <Button
                variant="outline"
                onClick={triggerSync}
                disabled={isSyncing || loading}
                className="w-full sm:w-auto"
                title="Manually trigger sync now"
              >
                <RefreshCw
                  className={`mr-2 h-4 w-4 ${isSyncing ? "animate-spin" : ""}`}
                />
                {isSyncing ? "Syncing..." : "Sync Now"}
              </Button>
              <Button
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="w-full sm:w-auto"
              >
                {uploading ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Upload className="mr-2 h-4 w-4" />
                )}
                {uploading ? "Uploading..." : "Upload PDF"}
              </Button>
            </div>
          </div>

          {/* Auto-sync info banner */}
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-lg bg-primary/5 border border-primary/15 p-3 mb-4 flex items-start gap-2"
          >
            <RefreshCw className="h-4 w-4 text-primary mt-0.5 shrink-0" />
            <p className="text-xs text-muted-foreground">
              <span className="font-medium text-foreground">Auto-sync is active.</span>{" "}
              Files are automatically checked every 5 minutes and stale entries are
              removed. You can also sync manually anytime.
            </p>
          </motion.div>

          {/* Security warning */}
          <div className="rounded-lg bg-destructive/10 border border-destructive/20 p-3 mb-6 flex items-start gap-2">
            <AlertCircle className="h-4 w-4 text-destructive mt-0.5 shrink-0" />
            <p className="text-xs text-muted-foreground">
              ⚠️ Bot token is exposed in the browser. This is suitable for internal/demo
              use only.
            </p>
          </div>

          {/* Loading */}
          {loading && (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}

          {/* Empty state */}
          {!loading && files.length === 0 && (
            <div className="text-center py-20">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-1">No files yet</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Upload your first PDF to get started
              </p>
              <Button onClick={() => fileRef.current?.click()}>
                <Upload className="mr-2 h-4 w-4" /> Upload PDF
              </Button>
            </div>
          )}

          {/* File list */}
          <AnimatePresence>
            <div className="space-y-3">
              {files.map((f, i) => {
                const timeAgo = f.uploadedAt
                  ? formatDistanceToNow(f.uploadedAt.toDate(), { addSuffix: true })
                  : "just now";

                return (
                  <motion.div
                    key={f.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: i * 0.04 }}
                    className="glass-hover rounded-xl p-4 flex items-center gap-3"
                  >
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0 overflow-hidden">
                      <p className="font-medium text-sm truncate">{f.fileName}</p>
                      <div className="flex items-center gap-1.5 sm:gap-2 text-xs text-muted-foreground mt-0.5 flex-wrap">
                        <span>{formatSize(f.fileSize)}</span>
                        <span className="hidden sm:inline">•</span>
                        <span className="truncate max-w-[80px] sm:max-w-none">
                          {f.uploaderName}
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1 shrink-0">
                          <Clock size={10} />
                          {timeAgo}
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="secondary"
                      size="sm"
                      className="h-8 text-xs shrink-0"
                      disabled={downloading === f.fileId}
                      onClick={() => handleDownload(f.fileId, f.fileName)}
                    >
                      {downloading === f.fileId ? (
                        <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                      ) : (
                        <Download className="mr-1 h-3 w-3" />
                      )}
                      Download
                    </Button>
                  </motion.div>
                );
              })}
            </div>
          </AnimatePresence>

          {/* Footer sync info */}
          {!loading && files.length > 0 && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center text-xs text-muted-foreground mt-6"
            >
              {files.length} file{files.length !== 1 ? "s" : ""} · Auto-syncs every 5
              minutes
            </motion.p>
          )}
        </div>
      </div>
    </PageTransition>
  );
};

export default TelegramFiles;
