import PageTransition from "@/components/PageTransition";
import { Shield, FileWarning, AlertTriangle, Mail } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

const DMCAPolicy = () => {
  usePageMeta({ title: "DMCA Policy", description: "StudyNest's copyright and DMCA takedown policy." });
  return (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-3xl">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">Copyright & DMCA Policy</h1>
        <p className="text-sm text-muted-foreground mb-8">We respect intellectual property rights.</p>

        <div className="space-y-6">
          <div className="glass rounded-xl p-5 sm:p-6">
            <h2 className="font-semibold flex items-center gap-2 mb-3"><FileWarning className="h-5 w-5 text-primary" />Submitting a Takedown Request</h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-3">If you believe your copyrighted work has been shared without authorization, send a DMCA takedown notice including:</p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2"><span className="text-primary font-bold">1.</span>Your name and contact information</li>
              <li className="flex items-start gap-2"><span className="text-primary font-bold">2.</span>Description of the copyrighted work</li>
              <li className="flex items-start gap-2"><span className="text-primary font-bold">3.</span>URL or location of the infringing material on StudyNest</li>
              <li className="flex items-start gap-2"><span className="text-primary font-bold">4.</span>A statement of good faith belief</li>
              <li className="flex items-start gap-2"><span className="text-primary font-bold">5.</span>Your physical or electronic signature</li>
            </ul>
          </div>

          <div className="glass rounded-xl p-5 sm:p-6">
            <h2 className="font-semibold flex items-center gap-2 mb-3"><Shield className="h-5 w-5 text-primary" />How We Handle Plagiarised Assignments</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Upon receiving a valid takedown request, we will promptly remove the infringing content, notify the uploader, and provide them an opportunity to submit a counter-notice if they believe the removal was in error. Content remains removed during the dispute resolution process.
            </p>
          </div>

          <div className="glass rounded-xl p-5 sm:p-6">
            <h2 className="font-semibold flex items-center gap-2 mb-3"><AlertTriangle className="h-5 w-5 text-yellow-400" />Repeat Infringer Policy</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Users who receive three valid DMCA takedown notices will have their accounts permanently terminated. We maintain records of all takedown requests and actions taken.
            </p>
          </div>

          <div className="glass rounded-xl p-5 sm:p-6">
            <h2 className="font-semibold flex items-center gap-2 mb-3"><Mail className="h-5 w-5 text-primary" />Contact</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Send DMCA notices to: <a href="mailto:masspenmods@gmail.com" className="text-primary hover:underline font-medium">masspenmods@gmail.com</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  </PageTransition>
  );
};

export default DMCAPolicy;
