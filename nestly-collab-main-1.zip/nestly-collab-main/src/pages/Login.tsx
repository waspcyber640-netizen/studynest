import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BookOpen, Loader2 } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import PageTransition from "@/components/PageTransition";
import { getRedirectResult } from "firebase/auth";
import { auth } from "@/firebase/config";
import usePageMeta from "@/hooks/usePageMeta";

const Login = () => {
  usePageMeta({ title: "Log In", description: "Log in to your StudyNest account." });
  const { logIn, logInWithGoogle, user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Handle redirect result (fallback from signInWithRedirect)
  useEffect(() => {
    getRedirectResult(auth).then((result) => {
      if (result?.user) {
        toast.success("Welcome back!");
        navigate("/dashboard");
      }
    }).catch(() => {});
  }, [navigate]);

  // If user becomes authenticated (e.g. from onAuthStateChanged), redirect
  useEffect(() => {
    if (user && !loading) {
      navigate("/dashboard");
    }
  }, [user, loading, navigate]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const formData = new FormData(e.currentTarget);
    const submittedEmail = (formData.get("email") as string | null)?.trim() || email.trim();
    const submittedPassword = (formData.get("password") as string | null) || password;

    if (!submittedEmail || !submittedPassword) {
      toast.error("Please fill in all fields.");
      return;
    }

    setLoading(true);
    try {
      await logIn(submittedEmail, submittedPassword);
      toast.success("Welcome back!");
      navigate("/dashboard");
    } catch (err: any) {
      toast.error(err.message || "Invalid credentials.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    setLoading(true);
    try {
      const result = await logInWithGoogle();
      if (result.user) {
        if (result.isNewUser) {
          toast.success("Welcome! Let's complete your profile.");
          navigate("/complete-profile");
        } else {
          toast.success("Welcome back!");
          navigate("/dashboard");
        }
      }
      // If null, signInWithRedirect was used — page will reload
    } catch (err: any) {
      toast.error(err.message || "Google sign-in failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageTransition>
      <div className="min-h-screen flex items-center justify-center px-4 pt-20">
        <div className="glass rounded-2xl p-6 sm:p-8 w-full max-w-md">
          <div className="text-center mb-6">
            <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center mx-auto mb-4">
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">Welcome back</h1>
            <p className="text-sm text-muted-foreground mt-1">Log in to your StudyNest account</p>
          </div>
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" autoComplete="email" type="email" placeholder="you@university.edu" value={email} onChange={e => setEmail(e.target.value)} className="mt-1.5 bg-secondary/50 border-border/50" />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link to="/forgot-password" className="text-xs text-primary hover:underline">Forgot password?</Link>
              </div>
              <Input id="password" name="password" autoComplete="current-password" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} className="mt-1.5 bg-secondary/50 border-border/50" />
            </div>
            <Button className="w-full" type="submit" disabled={loading}>
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Log In
            </Button>
            <div className="relative my-3">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border/50" /></div>
              <div className="relative flex justify-center text-xs"><span className="bg-card px-2 text-muted-foreground">or</span></div>
            </div>
            <Button variant="outline" className="w-full" type="button" onClick={handleGoogle} disabled={loading}>
              <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
              Continue with Google
            </Button>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-5">
            Don't have an account? <Link to="/signup" className="text-primary hover:underline">Sign up</Link>
          </p>
        </div>
      </div>
    </PageTransition>
  );
};

export default Login;
