import PageTransition from "@/components/PageTransition";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { HelpCircle, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import usePageMeta from "@/hooks/usePageMeta";

const faqSections = [
  {
    title: "Getting Started",
    items: [
      { q: "What is StudyNest?", a: "StudyNest is a student collaboration platform where you can share assignments, form study groups, and collaborate with peers in real-time." },
      { q: "How do I create an account?", a: "Click 'Sign Up' on the homepage, fill in your details including your institution type (school or university), and you're ready to go!" },
      { q: "Is StudyNest free?", a: "Yes! StudyNest is completely free for students." },
    ],
  },
  {
    title: "Account & Profile",
    items: [
      { q: "How do I edit my profile?", a: "Go to the Profile page and click the Edit button to update your name, bio, and other details." },
      { q: "Can I change my institution?", a: "Currently, you can update your institution details by contacting support." },
      { q: "How do I delete my account?", a: "Go to Profile → Settings → Delete Account. This action is irreversible." },
    ],
  },
  {
    title: "Assignment Sharing",
    items: [
      { q: "What file types can I upload?", a: "You can upload PDF, DOCX, PPTX, XLSX, TXT, IPYNB, and ZIP files up to 25MB." },
      { q: "Who can see my assignments?", a: "Assignments uploaded from the feed are tagged as 'Universal' and visible to all users. Files uploaded from a group chat are only visible to group members." },
      { q: "Can I delete an uploaded assignment?", a: "Yes, you can delete assignments you've uploaded from your profile page." },
    ],
  },
  {
    title: "Study Groups",
    items: [
      { q: "How do I create a study group?", a: "Go to Groups → Create Group. Choose a name, subject, and whether it's public or private." },
      { q: "Can I leave a group?", a: "Yes, click the 'Leave' button on any group card. Group creators cannot leave their own groups." },
      { q: "Is there a member limit?", a: "Currently there is no hard limit on group members." },
    ],
  },
  {
    title: "Chat",
    items: [
      { q: "How does group chat work?", a: "Enter any group chat to send real-time messages and share attachments with group members." },
      { q: "Can I send files in chat?", a: "Yes! Use the paperclip icon in the chat to upload files directly to the group." },
    ],
  },
  {
    title: "Privacy & Safety",
    items: [
      { q: "How do I report a user?", a: "Use the report button on any profile, assignment, or comment. Our team reviews reports within 24 hours." },
      { q: "Can I block someone?", a: "Yes, go to People → find the user → click the shield icon to block them." },
      { q: "Is my data safe?", a: "We use Firebase's enterprise-grade security. Read our Privacy Policy for details." },
    ],
  },
  {
    title: "Technical Issues",
    items: [
      { q: "Why can't I upload files?", a: "Make sure your file is under 25MB and in a supported format. Check your internet connection." },
      { q: "The app is slow or not loading", a: "Try clearing your browser cache, disabling extensions, or switching to a different browser." },
      { q: "How do I report a bug?", a: "Use our Report a Bug page or email us directly at masspenmods@gmail.com." },
      { q: "How do I contact support?", a: "You can reach us anytime at masspenmods@gmail.com or through the Contact Us page." },
    ],
  },
];

const HelpCenter = () => {
  usePageMeta({ title: "Help Center", description: "Find answers to common questions about StudyNest." });
  const [search, setSearch] = useState("");

  const filteredSections = faqSections.map((s) => ({
    ...s,
    items: s.items.filter(
      (item) =>
        search === "" ||
        item.q.toLowerCase().includes(search.toLowerCase()) ||
        item.a.toLowerCase().includes(search.toLowerCase())
    ),
  })).filter((s) => s.items.length > 0);

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-3xl">
          <div className="flex items-center gap-3 mb-2">
            <HelpCircle className="h-7 w-7 text-primary" />
            <h1 className="text-2xl sm:text-3xl font-bold">Help Center</h1>
          </div>
          <p className="text-sm text-muted-foreground mb-6">Find answers to common questions or email us at <a href="mailto:masspenmods@gmail.com" className="text-primary hover:underline">masspenmods@gmail.com</a>.</p>

          <div className="relative mb-8">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search for help..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-secondary/50 border-border/50"
            />
          </div>

          {filteredSections.length === 0 && (
            <div className="text-center py-16">
              <HelpCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-sm text-muted-foreground">No results found. Try a different search term.</p>
            </div>
          )}

          <div className="space-y-6">
            {filteredSections.map((section) => (
              <div key={section.title}>
                <h2 className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">{section.title}</h2>
                <Accordion type="single" collapsible className="glass rounded-xl overflow-hidden">
                  {section.items.map((item, i) => (
                    <AccordionItem key={i} value={`${section.title}-${i}`} className="border-border/30">
                      <AccordionTrigger className="px-5 py-4 text-sm font-medium hover:no-underline">{item.q}</AccordionTrigger>
                      <AccordionContent className="px-5 pb-4 text-sm text-muted-foreground">{item.a}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default HelpCenter;
