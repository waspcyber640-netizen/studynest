import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Camera, Tags, UserPlus, Users, ArrowRight, SkipForward, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import { useAuth } from "@/context/AuthContext";
import { subjects } from "@/data/mock";
import usePageMeta from "@/hooks/usePageMeta";

const Onboarding = () => {
  usePageMeta({ title: "Getting Started", description: "Complete your StudyNest profile setup.", noindex: true });
  const navigate = useNavigate();
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const totalSteps = 4;
  const progress = (step / totalSteps) * 100;

  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);

  const toggleSubject = (s: string) => {
    setSelectedSubjects((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]
    );
  };

  const next = () => {
    if (step < totalSteps) setStep(step + 1);
    else navigate("/dashboard");
  };

  const skip = () => next();

  const stepContent: Record<number, { icon: any; title: string; desc: string }> = {
    1: { icon: Camera, title: "Upload Profile Photo", desc: "Add a photo so your peers can recognize you." },
    2: { icon: Tags, title: "Pick Your Subjects", desc: "Select subjects you're interested in to get relevant content." },
    3: { icon: UserPlus, title: "Find Students", desc: "Follow students from your class or department." },
    4: { icon: Users, title: "Join a Study Group", desc: "Find your first study group and start collaborating." },
  };

  const currentStep = stepContent[step];

  return (
    <PageTransition>
      <div className="min-h-screen flex flex-col px-4 pt-20 pb-8">
        <div className="container mx-auto max-w-lg flex-1 flex flex-col">
          {/* Progress */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">Step {step} of {totalSteps}</span>
              <Button variant="ghost" size="sm" className="text-xs text-muted-foreground" onClick={skip}>
                <SkipForward className="mr-1 h-3 w-3" />Skip
              </Button>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Step Content */}
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col"
            >
              <div className="glass rounded-2xl p-6 sm:p-8 flex-1 flex flex-col items-center justify-center text-center">
                <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-5">
                  <currentStep.icon className="h-8 w-8 text-primary" />
                </div>
                <h2 className="text-xl font-bold mb-2">{currentStep.title}</h2>
                <p className="text-sm text-muted-foreground mb-6">{currentStep.desc}</p>

                {step === 1 && (
                  <div className="w-full max-w-xs">
                    <div className="h-32 w-32 rounded-full border-2 border-dashed border-border/50 flex items-center justify-center mx-auto mb-4 cursor-pointer hover:border-primary/50 transition-colors">
                      <Camera className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <p className="text-xs text-muted-foreground">Tap to upload (optional)</p>
                  </div>
                )}

                {step === 2 && (
                  <div className="flex flex-wrap gap-2 justify-center max-w-sm">
                    {subjects.filter(s => s !== "All" && s !== "Custom").map((s) => (
                      <button
                        key={s}
                        onClick={() => toggleSubject(s)}
                        className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                          selectedSubjects.includes(s)
                            ? "bg-primary text-primary-foreground border-primary"
                            : "border-border/50 text-muted-foreground hover:border-primary/50"
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                )}

                {step === 3 && (
                  <div className="w-full max-w-xs space-y-3">
                    {["Student A", "Student B", "Student C"].map((name) => (
                      <div key={name} className="flex items-center gap-3 glass rounded-xl p-3">
                        <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary">
                          {name[0]}
                        </div>
                        <span className="text-sm flex-1">{name}</span>
                        <Button size="sm" variant="outline" className="h-7 text-xs">Follow</Button>
                      </div>
                    ))}
                  </div>
                )}

                {step === 4 && (
                  <div className="w-full max-w-xs space-y-3">
                    {["Math Study Group", "Physics Lab", "CS Algorithms"].map((name) => (
                      <div key={name} className="flex items-center gap-3 glass rounded-xl p-3">
                        <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Users className="h-4 w-4 text-primary" />
                        </div>
                        <span className="text-sm flex-1">{name}</span>
                        <Button size="sm" className="h-7 text-xs">Join</Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <Button className="w-full mt-6" onClick={next}>
                {step === totalSteps ? (
                  <><CheckCircle className="mr-2 h-4 w-4" />Get Started</>
                ) : (
                  <>Continue<ArrowRight className="ml-2 h-4 w-4" /></>
                )}
              </Button>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </PageTransition>
  );
};

export default Onboarding;
