import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";
import { Heart, Target, Users, Lightbulb, BookOpen, Globe } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

const values = [
  { icon: BookOpen, title: "Education First", desc: "Everything we build serves the goal of better learning outcomes." },
  { icon: Users, title: "Collaboration", desc: "Learning is better together. We foster genuine peer connections." },
  { icon: Heart, title: "Inclusivity", desc: "Every student deserves access to quality study resources." },
  { icon: Lightbulb, title: "Innovation", desc: "We constantly improve how students discover and share knowledge." },
];

const team = [
  { name: "Mahesh Dubey", role: "Founder & CEO", initials: "MD" },
  { name: "Community", role: "Contributors", initials: "🌍" },
];

const AboutUs = () => {
  usePageMeta({ title: "About Us", description: "Learn about StudyNest's mission to make student collaboration easier." });
  return (
  <PageTransition>
    <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
      <div className="container mx-auto max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-2xl sm:text-4xl font-bold mb-4">About <span className="gradient-text">StudyNest</span></h1>
          <p className="text-muted-foreground max-w-2xl mx-auto text-sm sm:text-base">
            Built by students, for students. StudyNest is on a mission to make collaborative learning accessible to everyone.
          </p>
        </motion.div>

        {/* Mission */}
        <div className="glass rounded-2xl p-6 sm:p-10 mb-8 text-center glow">
          <Target className="h-10 w-10 text-primary mx-auto mb-4" />
          <h2 className="text-xl sm:text-2xl font-bold mb-3">Our Mission</h2>
          <p className="text-sm sm:text-base text-muted-foreground max-w-xl mx-auto leading-relaxed">
            To empower every student with the tools to share knowledge, collaborate effectively, and achieve academic excellence — regardless of their background or institution.
          </p>
        </div>

        {/* Story */}
        <div className="glass rounded-xl p-6 sm:p-8 mb-8">
          <h2 className="text-lg font-bold mb-3 flex items-center gap-2"><Globe className="h-5 w-5 text-primary" />Our Story</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            StudyNest was born from a simple observation: students everywhere struggle to find and share quality study materials. Founded by Mahesh Dubey, StudyNest started as a small project to help classmates share notes and has grown into a platform connecting students across institutions. We believe that when students help each other, everyone succeeds.
          </p>
        </div>

        {/* Values */}
        <h2 className="text-lg font-bold mb-4">Core Values</h2>
        <div className="grid sm:grid-cols-2 gap-4 mb-8">
          {values.map((v, i) => (
            <motion.div key={v.title} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="glass-hover rounded-xl p-5 flex items-start gap-4">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <v.icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-sm mb-1">{v.title}</h3>
                <p className="text-xs text-muted-foreground">{v.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Team */}
        <h2 className="text-lg font-bold mb-4">The Team</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {team.map((t, i) => (
            <motion.div key={t.name} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="glass-hover rounded-xl p-5 text-center">
              <div className="h-14 w-14 rounded-full bg-primary/20 flex items-center justify-center text-lg font-bold text-primary mx-auto mb-3">{t.initials}</div>
              <h3 className="font-semibold text-sm">{t.name}</h3>
              <p className="text-xs text-muted-foreground mt-0.5">{t.role}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  </PageTransition>
  );
};

export default AboutUs;
