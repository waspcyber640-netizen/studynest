import { FileText, Users, Upload, School, GraduationCap, UserPlus, Heart, Edit2, Save, X } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import { useState, useEffect } from "react";
import { subscribeToFollowers, subscribeToFollowing } from "@/services/connectionService";
import { subscribeToAssignments, Assignment } from "@/services/assignmentService";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "@/firebase/config";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import usePageMeta from "@/hooks/usePageMeta";

const Profile = () => {
  usePageMeta({ title: "Profile", description: "Manage your StudyNest profile, followers, and shared assignments.", noindex: true });
  const { profile, user } = useAuth();
  const [followerCount, setFollowerCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [myAssignments, setMyAssignments] = useState<Assignment[]>([]);
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [editBio, setEditBio] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    const unsubs = [
      subscribeToFollowers(user.uid, (c) => setFollowerCount(c.length)),
      subscribeToFollowing(user.uid, (c) => setFollowingCount(c.length)),
      subscribeToAssignments((data) => {
        setMyAssignments(data.filter((a) => a.uploaderId === user.uid));
      }),
    ];
    return () => unsubs.forEach((u) => u());
  }, [user]);

  useEffect(() => {
    if (profile) {
      setEditName(profile.name);
      setEditBio(profile.bio);
    }
  }, [profile]);

  const displayName = profile?.name || user?.displayName || "Student";
  const initials = displayName.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  const bio = profile?.bio || "No bio yet.";

  const institutionInfo = profile?.institutionType === "school"
    ? `${profile.schoolName || "School"} · Class ${profile.className || "?"}`
    : profile?.institutionType === "university"
    ? `${profile.university || "University"} · ${profile.department || ""} ${profile.year ? `· ${profile.year}` : ""}`
    : "";

  const handleSaveProfile = async () => {
    if (!user) return;
    setSaving(true);
    try {
      await updateDoc(doc(db, "users", user.uid), {
        name: editName.trim() || displayName,
        bio: editBio.trim(),
      });
      toast.success("Profile updated!");
      setEditing(false);
    } catch (err: any) {
      toast.error(err.message || "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  const stats = [
    { icon: Upload, label: "Uploads", value: myAssignments.length },
    { icon: Heart, label: "Followers", value: followerCount, link: "/people" },
    { icon: UserPlus, label: "Following", value: followingCount, link: "/people" },
    { icon: Users, label: "Groups", value: 0 },
    { icon: FileText, label: "Downloads", value: 0 },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-4xl pt-2">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass rounded-2xl p-4 sm:p-8 text-center mb-6"
          >
            {/* Avatar */}
            <div className="h-16 w-16 sm:h-20 sm:w-20 rounded-full bg-primary/20 flex items-center justify-center text-xl sm:text-2xl font-bold text-primary mx-auto mb-3">
              {initials}
            </div>

            {editing ? (
              <div className="max-w-sm mx-auto space-y-3 text-left">
                <div>
                  <Label>Name</Label>
                  <Input value={editName} onChange={(e) => setEditName(e.target.value)} className="mt-1 bg-secondary/50 border-border/50" />
                </div>
                <div>
                  <Label>Bio</Label>
                  <Textarea value={editBio} onChange={(e) => setEditBio(e.target.value)} className="mt-1 bg-secondary/50 border-border/50 min-h-[60px]" placeholder="Tell others about yourself..." />
                </div>
                <div className="flex gap-2 justify-center">
                  <Button size="sm" onClick={handleSaveProfile} disabled={saving}>
                    <Save className="h-3 w-3 mr-1" />{saving ? "Saving..." : "Save"}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setEditing(false)}>
                    <X className="h-3 w-3 mr-1" />Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-bold truncate max-w-[70vw]">{displayName}</h1>
                  <Link to="/profile/edit">
                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0 shrink-0">
                      <Edit2 className="h-3.5 w-3.5 text-muted-foreground" />
                    </Button>
                  </Link>
                </div>

                {profile?.institutionType && (
                  <div className="flex items-center justify-center gap-1.5 mt-1.5">
                    {profile.institutionType === "school" ? (
                      <School className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    ) : (
                      <GraduationCap className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    )}
                    <span className="text-xs sm:text-sm text-muted-foreground truncate">{institutionInfo}</span>
                  </div>
                )}

                <p className="text-xs sm:text-sm text-muted-foreground mt-2 max-w-md mx-auto line-clamp-3">{bio}</p>
              </>
            )}

            {/* Stats row — horizontally scrollable on mobile */}
            <div className="mt-5 -mx-4 sm:mx-0">
              <div className="flex sm:justify-center gap-2 sm:gap-6 overflow-x-auto px-4 sm:px-0 pb-1 scrollbar-hide">
                {stats.map(s => (
                  <Link
                    key={s.label}
                    to={s.link || "#"}
                    className="flex flex-col items-center min-w-[60px] shrink-0 hover:opacity-80 transition-opacity"
                  >
                    <div className="h-9 w-9 sm:h-10 sm:w-10 rounded-lg bg-primary/10 flex items-center justify-center mb-1">
                      <s.icon className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                    </div>
                    <p className="text-base sm:text-lg font-bold leading-tight">{s.value}</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">{s.label}</p>
                  </Link>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Assignments section */}
          <h2 className="text-base sm:text-lg font-semibold mb-3">My Shared Assignments</h2>
          {myAssignments.length === 0 ? (
            <div className="glass rounded-xl p-6 text-center">
              <FileText className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No assignments shared yet.</p>
              <Link to="/assignments">
                <Button size="sm" className="mt-3">
                  <Upload className="mr-1.5 h-3.5 w-3.5" />Upload First
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-2.5">
              {myAssignments.map((a, i) => (
                <motion.div
                  key={a.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="glass-hover rounded-xl p-3 sm:p-4 flex items-center gap-3"
                >
                  <div className="h-9 w-9 sm:h-10 sm:w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <FileText className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{a.title}</p>
                    <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                      <span className="text-[10px] sm:text-xs px-1.5 py-0.5 rounded-full bg-primary/20 text-primary">{a.subject}</span>
                      {a.isPrivate && <span className="text-[10px] px-1.5 py-0.5 rounded bg-destructive/20 text-destructive">Private</span>}
                      <span className="text-[10px] sm:text-xs text-muted-foreground">{a.likes || 0} likes</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  );
};

export default Profile;
