import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Upload, Users, FileText, ArrowRight, Clock, Search, Loader2, UserPlus } from "lucide-react";
import { subjectColors } from "@/data/mock";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import { SkeletonList } from "@/components/LoadingSkeletons";
import UploadModal from "@/components/UploadModal";
import { useAuth } from "@/context/AuthContext";
import usePageMeta from "@/hooks/usePageMeta";
import { useState, useEffect } from "react";
import { subscribeToAssignments, Assignment } from "@/services/assignmentService";
import { formatDistanceToNow } from "date-fns";

const Dashboard = () => {
  usePageMeta({ title: "Dashboard", description: "Your StudyNest dashboard — recent assignments, groups, and activity.", noindex: true });
  const { profile, user } = useAuth();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = subscribeToAssignments((data) => {
      setAssignments(data);
      setLoading(false);
    });
    return unsub;
  }, []);

  const displayName = profile?.name || user?.displayName || "Student";
  const firstName = displayName.split(" ")[0];

  const recentAssignments = assignments
    .filter(
      (a) =>
        search === "" ||
        a.title.toLowerCase().includes(search.toLowerCase()) ||
        a.subject.toLowerCase().includes(search.toLowerCase())
    )
    .slice(0, 4);

  return (
    <PageTransition>
      <div className="min-h-screen pt-20 px-3 sm:px-4 pb-24 md:pb-12">
        <div className="container mx-auto max-w-6xl pt-2">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl sm:text-3xl font-bold">
              Welcome back, <span className="gradient-text">{firstName}</span>
            </h1>
            <p className="text-muted-foreground mt-1 text-sm">
              Here's what's happening in your study network.
            </p>
          </div>

          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search assignments by title or subject..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-secondary/50 border-border/50"
            />
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {[
              { icon: Upload, label: "Upload Assignment", onClick: () => setUploadOpen(true) },
              { icon: Users, label: "Study Groups", to: "/groups" },
              { icon: UserPlus, label: "People", to: "/people" },
              { icon: FileText, label: "Browse Feed", to: "/assignments" },
            ].map((action, i) => (
              <motion.div
                key={action.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                {action.to ? (
                  <Link
                    to={action.to}
                    className="glass-hover rounded-xl p-4 flex flex-col items-center gap-2 text-center"
                  >
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <action.icon className="h-5 w-5 text-primary" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium">{action.label}</span>
                  </Link>
                ) : (
                  <button
                    onClick={action.onClick}
                    className="glass-hover rounded-xl p-4 flex flex-col items-center gap-2 text-center w-full"
                  >
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <action.icon className="h-5 w-5 text-primary" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium">{action.label}</span>
                  </button>
                )}
              </motion.div>
            ))}
          </div>

          {/* Recent Assignments */}
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recent Assignments</h2>
            <Link
              to="/assignments"
              className="text-sm text-primary hover:underline flex items-center gap-1"
            >
              View all <ArrowRight size={14} />
            </Link>
          </div>

          {loading ? (
            <SkeletonList count={4} />
          ) : recentAssignments.length === 0 ? (
            <div className="text-center py-12 glass rounded-xl">
              <FileText className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground mb-3">No assignments yet.</p>
              <Button size="sm" onClick={() => setUploadOpen(true)}>
                <Upload className="mr-2 h-4 w-4" />Upload First
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {recentAssignments.map((a, i) => {
                const timeAgo = a.createdAt
                  ? formatDistanceToNow(a.createdAt.toDate(), { addSuffix: true })
                  : "just now";
                return (
                  <motion.div
                    key={a.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="glass-hover rounded-xl p-4 flex items-center gap-3 sm:gap-4"
                  >
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{a.title}</p>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full ${subjectColors[a.subject] || "bg-primary/20 text-primary"}`}
                        >
                          {a.subject}
                        </span>
                        {a.isPrivate && (
                          <span className="text-xs px-1.5 py-0.5 rounded bg-destructive/20 text-destructive">Private</span>
                        )}
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock size={10} />{timeAgo}
                        </span>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground uppercase hidden sm:block">
                      {a.fileType}
                    </span>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>
      <UploadModal open={uploadOpen} onOpenChange={setUploadOpen} />
    </PageTransition>
  );
};

export default Dashboard;
