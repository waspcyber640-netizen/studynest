import { Button } from "@/components/ui/button";
import { Mail, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import { useState } from "react";
import { toast } from "sonner";
import usePageMeta from "@/hooks/usePageMeta";

const EmailVerification = () => {
  usePageMeta({ title: "Verify Email", description: "Verify your email address to activate your StudyNest account.", noindex: true });
  const [resending, setResending] = useState(false);

  const handleResend = () => {
    setResending(true);
    setTimeout(() => {
      setResending(false);
      toast.success("Verification email resent!");
    }, 1500);
  };

  return (
    <PageTransition>
      <div className="min-h-screen flex items-center justify-center px-4 pt-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-6 sm:p-10 text-center max-w-md w-full">
          <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
            <Mail className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-xl font-bold mb-2">Check Your Email</h1>
          <p className="text-sm text-muted-foreground mb-6">
            We've sent a verification link to your email address. Click the link to verify your account and get started.
          </p>
          <Button onClick={handleResend} variant="outline" className="w-full" disabled={resending}>
            {resending ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            Resend Verification Email
          </Button>
          <p className="text-xs text-muted-foreground mt-4">Didn't receive it? Check your spam folder.</p>
        </motion.div>
      </div>
    </PageTransition>
  );
};

export default EmailVerification;
