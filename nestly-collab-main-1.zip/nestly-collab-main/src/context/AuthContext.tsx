import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
} from "firebase/auth";
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";
import { auth, googleProvider, db } from "@/firebase/config";

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  institutionType: "school" | "university" | "";
  // School fields
  schoolName: string;
  className: string; // e.g. "9", "10", "11", "12"
  // University fields
  university: string;
  department: string;
  year: string;
  // Common
  bio: string;
  avatar: string;
  skills: string[];
  reputation: number;
  createdAt: unknown;
}

interface SignUpData {
  email: string;
  password: string;
  name: string;
  institutionType: "school" | "university";
  schoolName?: string;
  className?: string;
  university?: string;
  department?: string;
  year?: string;
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signUp: (data: SignUpData) => Promise<void>;
  logIn: (email: string, password: string) => Promise<void>;
  logInWithGoogle: () => Promise<{ user: User | null; isNewUser: boolean }>;
  logOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

const buildFallbackProfile = (firebaseUser: User): UserProfile => ({
  uid: firebaseUser.uid,
  name: firebaseUser.displayName || "Student",
  email: firebaseUser.email || "",
  institutionType: "",
  schoolName: "",
  className: "",
  university: "",
  department: "",
  year: "",
  bio: "",
  avatar: firebaseUser.photoURL || "",
  skills: [],
  reputation: 0,
  createdAt: null,
});

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const ensureUserProfile = async (firebaseUser: User) => {
    const fallback = buildFallbackProfile(firebaseUser);
    try {
      const userRef = doc(db, "users", firebaseUser.uid);
      const snap = await getDoc(userRef);
      if (snap.exists()) {
        setProfile({ ...fallback, ...snap.data() } as UserProfile);
        return;
      }
      const newProfile: UserProfile = { ...fallback, createdAt: serverTimestamp() };
      await setDoc(userRef, newProfile);
      setProfile(newProfile);
    } catch (err) {
      console.warn("Firestore profile unavailable, using fallback:", err);
      setProfile(fallback);
    }
  };

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        setProfile((prev) => {
          if (prev && prev.uid === firebaseUser.uid) return prev;
          ensureUserProfile(firebaseUser);
          return prev;
        });
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const signUp = async (data: SignUpData) => {
    const cred = await createUserWithEmailAndPassword(auth, data.email, data.password);
    await updateProfile(cred.user, { displayName: data.name });

    const userProfile: UserProfile = {
      uid: cred.user.uid,
      name: data.name,
      email: data.email,
      institutionType: data.institutionType,
      schoolName: data.schoolName || "",
      className: data.className || "",
      university: data.university || "",
      department: data.department || "",
      year: data.year || "",
      bio: "",
      avatar: "",
      skills: [],
      reputation: 0,
      createdAt: serverTimestamp(),
    };

    try {
      await setDoc(doc(db, "users", cred.user.uid), userProfile);
    } catch (err) {
      console.warn("Could not save profile to Firestore:", err);
    }
    setProfile(userProfile);
  };

  const logIn = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email, password);
  };

  const logInWithGoogle = async (): Promise<{ user: User | null; isNewUser: boolean }> => {
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      
      // Check if user profile exists and is complete
      const userRef = doc(db, "users", cred.user.uid);
      const snap = await getDoc(userRef);
      const isNewUser = !snap.exists() || !snap.data()?.institutionType;
      
      await ensureUserProfile(cred.user);
      return { user: cred.user, isNewUser };
    } catch (err: any) {
      const code = err?.code || "";
      if (code === "auth/unauthorized-domain") {
        throw new Error(
          "This domain is not authorized for Google sign-in. Add lovableproject.com and lovable.app to Firebase Console → Authentication → Authorized domains."
        );
      }
      if (
        code === "auth/popup-blocked" ||
        code === "auth/popup-closed-by-user" ||
        code === "auth/cancelled-popup-request"
      ) {
        await signInWithRedirect(auth, googleProvider);
        return { user: null, isNewUser: false };
      }
      throw err;
    }
  };

  const logOut = async () => {
    await signOut(auth);
    setProfile(null);
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, signUp, logIn, logInWithGoogle, logOut, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
};
