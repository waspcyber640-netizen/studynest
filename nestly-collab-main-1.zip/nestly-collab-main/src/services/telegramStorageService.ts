import {
  collection,
  addDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  Timestamp,
  deleteDoc,
  doc,
  getDocs,
} from "firebase/firestore";
import { db } from "@/firebase/config";

// Telegram credentials loaded from environment variables.
// Set VITE_TELEGRAM_BOT_TOKEN and VITE_TELEGRAM_CHANNEL_ID in your .env or hosting environment.
const BOT_TOKEN = import.meta.env.VITE_TELEGRAM_BOT_TOKEN || "";
const CHANNEL_ID = import.meta.env.VITE_TELEGRAM_CHANNEL_ID || "";
const TG_API = `https://api.telegram.org/bot${BOT_TOKEN}`;

export interface TelegramFile {
  id: string;
  fileId: string;
  fileName: string;
  fileSize: number;
  uploadedAt: Timestamp | null;
  uploaderId: string;
  uploaderName: string;
}

// Upload PDF to Telegram channel, save metadata to Firestore
export const uploadPdfToTelegram = async (
  file: File,
  uploaderId: string,
  uploaderName: string
): Promise<void> => {
  if (!BOT_TOKEN || !CHANNEL_ID) {
    throw new Error(
      "Telegram credentials not configured. Set VITE_TELEGRAM_BOT_TOKEN and VITE_TELEGRAM_CHANNEL_ID environment variables."
    );
  }

  const formData = new FormData();
  formData.append("chat_id", CHANNEL_ID);
  formData.append("document", file);

  const res = await fetch(`${TG_API}/sendDocument`, {
    method: "POST",
    body: formData,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.description || "Telegram upload failed");
  }

  const data = await res.json();
  const doc = data.result?.document;
  if (!doc?.file_id) throw new Error("No file_id returned from Telegram");

  await addDoc(collection(db, "telegram_files"), {
    fileId: doc.file_id,
    fileName: file.name,
    fileSize: file.size,
    uploaderId,
    uploaderName,
    uploadedAt: serverTimestamp(),
  });
};

// Get temporary download URL for a file
export const getTelegramFileUrl = async (fileId: string): Promise<string> => {
  if (!BOT_TOKEN) {
    throw new Error("Telegram bot token not configured. Set VITE_TELEGRAM_BOT_TOKEN environment variable.");
  }

  const res = await fetch(`${TG_API}/getFile?file_id=${encodeURIComponent(fileId)}`);
  if (!res.ok) throw new Error("Failed to get file info");

  const data = await res.json();
  const filePath = data.result?.file_path;
  if (!filePath) throw new Error("No file_path returned");

  return `https://api.telegram.org/file/bot${BOT_TOKEN}/${filePath}`;
};

// Check if a file still exists in Telegram
export const checkTelegramFileExists = async (fileId: string): Promise<boolean> => {
  if (!BOT_TOKEN) return false;

  try {
    const res = await fetch(`${TG_API}/getFile?file_id=${encodeURIComponent(fileId)}`);
    const data = await res.json();
    return data.ok === true && !!data.result?.file_path;
  } catch {
    return false;
  }
};

// Sync Firestore with Telegram - remove entries for files that no longer exist
export const syncTelegramFiles = async (): Promise<{ removed: number; checked: number }> => {
  if (!BOT_TOKEN) {
    throw new Error("Telegram bot token not configured.");
  }

  const q = query(collection(db, "telegram_files"));
  const snapshot = await getDocs(q);

  let removed = 0;
  const checked = snapshot.docs.length;

  for (const docSnap of snapshot.docs) {
    const data = docSnap.data();
    const exists = await checkTelegramFileExists(data.fileId);

    if (!exists) {
      await deleteDoc(doc(db, "telegram_files", docSnap.id));
      removed++;
    }
  }

  return { removed, checked };
};

// Sync assignments - remove assignments whose Telegram files no longer exist
export const syncAssignmentFiles = async (): Promise<{ removed: number; checked: number }> => {
  if (!BOT_TOKEN) {
    return { removed: 0, checked: 0 };
  }

  const { getDocs: getAssignmentDocs, query: buildQuery, collection: getCollection, deleteDoc: removeDoc, doc: getDocRef } = await import("firebase/firestore");
  
  const q = buildQuery(getCollection(db, "assignments"));
  const snapshot = await getAssignmentDocs(q);

  let removed = 0;
  let checked = 0;

  for (const docSnap of snapshot.docs) {
    const data = docSnap.data();
    if (!data.fileUrl || !data.fileUrl.startsWith("tg://")) continue;
    
    checked++;
    const fileId = data.fileUrl.replace("tg://", "");
    const exists = await checkTelegramFileExists(fileId);

    if (!exists) {
      await removeDoc(getDocRef(db, "assignments", docSnap.id));
      removed++;
    }
  }

  return { removed, checked };
};

// Real-time listener
export const subscribeToTelegramFiles = (
  callback: (files: TelegramFile[]) => void
) => {
  const q = query(collection(db, "telegram_files"), orderBy("uploadedAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    const files = snapshot.docs.map((d) => ({
      id: d.id,
      ...d.data(),
    })) as TelegramFile[];
    callback(files);
  });
};
