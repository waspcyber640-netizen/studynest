import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  orderBy,
  where,
  onSnapshot,
  serverTimestamp,
  arrayUnion,
  arrayRemove,
  Timestamp,
} from "firebase/firestore";
import { db } from "@/firebase/config";

export interface Group {
  id: string;
  name: string;
  subject: string;
  description: string;
  isPublic: boolean;
  creatorId: string;
  creatorName: string;
  memberIds: string[];
  memberCount: number;
  createdAt: Timestamp | null;
}

export interface ChatMessage {
  id: string;
  groupId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  createdAt: Timestamp | null;
}

// ─── Groups ──────────────────────────────────────────

export const subscribeToGroups = (
  callback: (groups: Group[]) => void,
  onError?: (error: Error) => void
) => {
  const q = query(collection(db, "groups"), orderBy("createdAt", "desc"));
  return onSnapshot(
    q,
    (snapshot) => {
      const groups = snapshot.docs.map((d) => ({ id: d.id, ...d.data() })) as Group[];
      callback(groups);
    },
    (error) => {
      console.warn("Groups listener error:", error);
      callback([]);
      onError?.(error);
    }
  );
};

export const getGroup = async (groupId: string): Promise<Group | null> => {
  try {
    const snap = await getDoc(doc(db, "groups", groupId));
    if (!snap.exists()) return null;
    return { id: snap.id, ...snap.data() } as Group;
  } catch {
    return null;
  }
};

export const createGroup = async (data: {
  name: string;
  subject: string;
  description: string;
  isPublic: boolean;
  creatorId: string;
  creatorName: string;
}) => {
  return addDoc(collection(db, "groups"), {
    ...data,
    memberIds: [data.creatorId],
    memberCount: 1,
    createdAt: serverTimestamp(),
  });
};

export const joinGroup = async (groupId: string, userId: string) => {
  const ref = doc(db, "groups", groupId);
  const snap = await getDoc(ref);
  if (!snap.exists()) return;
  const data = snap.data();
  if ((data.memberIds || []).includes(userId)) return;
  await updateDoc(ref, {
    memberIds: arrayUnion(userId),
    memberCount: (data.memberCount || 0) + 1,
  });
};

export const leaveGroup = async (groupId: string, userId: string) => {
  const ref = doc(db, "groups", groupId);
  const snap = await getDoc(ref);
  if (!snap.exists()) return;
  const data = snap.data();
  if (!(data.memberIds || []).includes(userId)) return;
  await updateDoc(ref, {
    memberIds: arrayRemove(userId),
    memberCount: Math.max((data.memberCount || 1) - 1, 0),
  });
};

export const deleteGroup = async (groupId: string) => {
  await deleteDoc(doc(db, "groups", groupId));
};

// ─── Chat Messages ───────────────────────────────────

export const subscribeToMessages = (
  groupId: string,
  callback: (messages: ChatMessage[]) => void,
  onError?: (error: Error) => void
) => {
  const q = query(
    collection(db, "groups", groupId, "messages"),
    orderBy("createdAt", "asc")
  );
  return onSnapshot(
    q,
    (snapshot) => {
      const messages = snapshot.docs.map((d) => ({ id: d.id, ...d.data() })) as ChatMessage[];
      callback(messages);
    },
    (error) => {
      console.warn("Messages listener error:", error);
      callback([]);
      onError?.(error);
    }
  );
};

export const sendMessage = async (
  groupId: string,
  data: { userId: string; userName: string; userAvatar: string; text: string }
) => {
  await addDoc(collection(db, "groups", groupId, "messages"), {
    groupId,
    ...data,
    createdAt: serverTimestamp(),
  });
};

// ─── Notifications ───────────────────────────────────

export interface AppNotification {
  id: string;
  userId: string;
  type: "group_join" | "new_message" | "group_invite";
  title: string;
  body: string;
  read: boolean;
  groupId?: string;
  createdAt: Timestamp | null;
}

export const subscribeToNotifications = (
  userId: string,
  callback: (notifications: AppNotification[]) => void
) => {
  const q = query(
    collection(db, "notifications"),
    where("userId", "==", userId),
    orderBy("createdAt", "desc")
  );
  return onSnapshot(
    q,
    (snapshot) => {
      const notifs = snapshot.docs.map((d) => ({ id: d.id, ...d.data() })) as AppNotification[];
      callback(notifs);
    },
    (error) => {
      console.warn("Notifications listener error:", error);
      callback([]);
    }
  );
};

export const markNotificationRead = async (notifId: string) => {
  await updateDoc(doc(db, "notifications", notifId), { read: true });
};

export const createNotification = async (data: {
  userId: string;
  type: "group_join" | "new_message" | "group_invite";
  title: string;
  body: string;
  groupId?: string;
}) => {
  await addDoc(collection(db, "notifications"), {
    ...data,
    read: false,
    createdAt: serverTimestamp(),
  });
};
