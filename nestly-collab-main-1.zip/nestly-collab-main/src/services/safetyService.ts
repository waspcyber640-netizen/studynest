import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  addDoc,
  query,
  where,
  onSnapshot,
  getDocs,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";
import { db } from "@/firebase/config";

export interface Report {
  id: string;
  reporterId: string;
  reportedUserId: string;
  contentId?: string;
  contentType: "assignment" | "comment" | "group" | "user" | "session";
  reason: string;
  details: string;
  status: "pending" | "reviewed" | "resolved";
  createdAt: Timestamp | null;
}

export interface Block {
  id: string;
  blockerId: string;
  blockedId: string;
  createdAt: Timestamp | null;
}

// Report content or user
export const reportContent = async (data: Omit<Report, "id" | "status" | "createdAt">) => {
  return addDoc(collection(db, "reports"), {
    ...data,
    status: "pending",
    createdAt: serverTimestamp(),
  });
};

// Block a user
export const blockUser = async (blockerId: string, blockedId: string) => {
  const docId = `${blockerId}_${blockedId}`;
  await setDoc(doc(db, "blocks", docId), {
    blockerId,
    blockedId,
    createdAt: serverTimestamp(),
  });
};

// Unblock a user
export const unblockUser = async (blockerId: string, blockedId: string) => {
  const docId = `${blockerId}_${blockedId}`;
  await deleteDoc(doc(db, "blocks", docId));
};

// Subscribe to blocked users list
export const subscribeToBlockedUsers = (
  userId: string,
  callback: (blockedIds: string[]) => void
) => {
  const q = query(collection(db, "blocks"), where("blockerId", "==", userId));
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => d.data().blockedId));
  });
};

// Check if user is blocked (one-time)
export const isUserBlocked = async (blockerId: string, blockedId: string): Promise<boolean> => {
  const q = query(
    collection(db, "blocks"),
    where("blockerId", "==", blockerId),
    where("blockedId", "==", blockedId)
  );
  const snap = await getDocs(q);
  return !snap.empty;
};
