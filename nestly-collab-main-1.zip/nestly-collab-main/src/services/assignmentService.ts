import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  query,
  orderBy,
  where,
  onSnapshot,
  serverTimestamp,
  increment,
  arrayUnion,
  arrayRemove,
  Timestamp,
} from "firebase/firestore";
import { db } from "@/firebase/config";

export interface Assignment {
  id: string;
  title: string;
  description: string;
  subject: string;
  tags: string[];
  fileUrl: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  uploaderId: string;
  uploaderName: string;
  uploaderAvatar: string;
  // Targeting fields
  institutionType: string; // "school" | "university"
  className: string;       // for school: "9", "10", etc.
  department: string;      // for university
  university: string;
  schoolName: string;
  isPrivate: boolean;
  groupId?: string;
  groupName?: string;
  likes: number;
  likedBy: string[];
  savedBy: string[];
  commentCount: number;
  createdAt: Timestamp | null;
}

export interface Comment {
  id: string;
  assignmentId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  createdAt: Timestamp | null;
}

// Real-time assignments listener
export const subscribeToAssignments = (
  callback: (assignments: Assignment[]) => void,
  onError?: (error: Error) => void
) => {
  const q = query(collection(db, "assignments"), orderBy("createdAt", "desc"));
  return onSnapshot(
    q,
    (snapshot) => {
      const assignments = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Assignment[];
      callback(assignments);
    },
    (error) => {
      console.warn("Firestore listener error:", error);
      callback([]);
      onError?.(error);
    }
  );
};

// Upload file to Telegram channel, return fileId as the "url"
export const uploadFile = async (
  file: File,
  onProgress: (progress: number) => void
): Promise<{ url: string; fileName: string; fileType: string; fileSize: number }> => {
  const BOT_TOKEN = "8623349565:AAF9r1qofHs6QXL7Sxn7_BrCzrvmj76aYM0";
  const CHANNEL_ID = "-1003792965048";
  const TG_API = `https://api.telegram.org/bot${BOT_TOKEN}`;

  onProgress(10); // Start progress indication

  const formData = new FormData();
  formData.append("chat_id", CHANNEL_ID);
  formData.append("document", file);

  onProgress(30);

  const res = await fetch(`${TG_API}/sendDocument`, {
    method: "POST",
    body: formData,
  });

  onProgress(70);

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.description || "Telegram upload failed");
  }

  const data = await res.json();
  const doc = data.result?.document;
  if (!doc?.file_id) throw new Error("No file_id returned from Telegram");

  onProgress(90);

  const ext = file.name.split(".").pop() || "";
  // Store file_id as the URL — we'll resolve it to a real URL on download
  return { url: `tg://${doc.file_id}`, fileName: file.name, fileType: ext, fileSize: file.size };
};

// Create assignment document
export const createAssignment = async (data: {
  title: string;
  description: string;
  subject: string;
  tags: string[];
  fileUrl: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  uploaderId: string;
  uploaderName: string;
  uploaderAvatar: string;
  institutionType: string;
  className: string;
  department: string;
  university: string;
  schoolName: string;
  isPrivate?: boolean;
  groupId?: string;
  groupName?: string;
}) => {
  const docRef = await addDoc(collection(db, "assignments"), {
    ...data,
    isPrivate: data.isPrivate || false,
    likes: 0,
    likedBy: [],
    savedBy: [],
    commentCount: 0,
    createdAt: serverTimestamp(),
  });

  // Create notification for all users about new upload
  // In production, you'd query relevant users. For now we store it as a broadcast-style notification.
  await addDoc(collection(db, "notifications"), {
    userId: "__broadcast__",
    uploaderId: data.uploaderId,
    type: "new_upload",
    title: "New Notes Uploaded",
    body: `${data.uploaderName} uploaded "${data.title}"`,
    read: false,
    createdAt: serverTimestamp(),
  });

  return docRef;
};

// Toggle like
export const toggleLike = async (assignmentId: string, userId: string) => {
  const docRef = doc(db, "assignments", assignmentId);
  const snap = await getDoc(docRef);
  if (!snap.exists()) return;
  const data = snap.data();
  const isLiked = (data.likedBy || []).includes(userId);
  await updateDoc(docRef, {
    likedBy: isLiked ? arrayRemove(userId) : arrayUnion(userId),
    likes: increment(isLiked ? -1 : 1),
  });
};

// Toggle save
export const toggleSave = async (assignmentId: string, userId: string) => {
  const docRef = doc(db, "assignments", assignmentId);
  const snap = await getDoc(docRef);
  if (!snap.exists()) return;
  const data = snap.data();
  const isSaved = (data.savedBy || []).includes(userId);
  await updateDoc(docRef, {
    savedBy: isSaved ? arrayRemove(userId) : arrayUnion(userId),
  });
};

// Comments - real-time listener
export const subscribeToComments = (assignmentId: string, callback: (comments: Comment[]) => void) => {
  const q = query(
    collection(db, "assignments", assignmentId, "comments"),
    orderBy("createdAt", "asc")
  );
  return onSnapshot(q, (snapshot) => {
    const comments = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as Comment[];
    callback(comments);
  });
};

// Add comment
export const addComment = async (
  assignmentId: string,
  data: { userId: string; userName: string; userAvatar: string; text: string }
) => {
  await addDoc(collection(db, "assignments", assignmentId, "comments"), {
    assignmentId,
    ...data,
    createdAt: serverTimestamp(),
  });
  await updateDoc(doc(db, "assignments", assignmentId), {
    commentCount: increment(1),
  });
};

// Delete assignment
export const deleteAssignment = async (assignmentId: string) => {
  await deleteDoc(doc(db, "assignments", assignmentId));
};
