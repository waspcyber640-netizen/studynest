import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  query,
  where,
  onSnapshot,
  getDocs,
  serverTimestamp,
  Timestamp,
  addDoc,
  limit,
} from "firebase/firestore";
import { db } from "@/firebase/config";

export interface Connection {
  id: string;
  followerId: string;
  followingId: string;
  createdAt: Timestamp | null;
}

export interface PublicProfile {
  uid: string;
  name: string;
  avatar: string;
  institutionType: string;
  className: string;
  department: string;
  university: string;
  schoolName: string;
  bio: string;
}

// Follow a user
export const followUser = async (followerId: string, followingId: string) => {
  const docId = `${followerId}_${followingId}`;
  await setDoc(doc(db, "connections", docId), {
    followerId,
    followingId,
    createdAt: serverTimestamp(),
  });

  // Create notification for the followed user
  await addDoc(collection(db, "notifications"), {
    userId: followingId,
    title: "New Follower",
    body: "Someone started following you!",
    type: "follow",
    read: false,
    createdAt: serverTimestamp(),
  });
};

// Unfollow a user
export const unfollowUser = async (followerId: string, followingId: string) => {
  const docId = `${followerId}_${followingId}`;
  await deleteDoc(doc(db, "connections", docId));
};

// Check if following
export const subscribeToFollowStatus = (
  followerId: string,
  followingId: string,
  callback: (isFollowing: boolean) => void
) => {
  const docId = `${followerId}_${followingId}`;
  return onSnapshot(doc(db, "connections", docId), (snap) => {
    callback(snap.exists());
  });
};

// Get followers count (real-time)
export const subscribeToFollowers = (
  userId: string,
  callback: (followers: Connection[]) => void
) => {
  const q = query(collection(db, "connections"), where("followingId", "==", userId));
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Connection)));
  });
};

// Get following count (real-time)
export const subscribeToFollowing = (
  userId: string,
  callback: (following: Connection[]) => void
) => {
  const q = query(collection(db, "connections"), where("followerId", "==", userId));
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Connection)));
  });
};

// Get suggested people (same class/department, not already following)
export const getSuggestedPeople = async (
  currentUserId: string,
  institutionType: string,
  className?: string,
  department?: string
): Promise<PublicProfile[]> => {
  let q;
  if (institutionType === "school" && className) {
    q = query(
      collection(db, "users"),
      where("institutionType", "==", "school"),
      where("className", "==", className),
      limit(20)
    );
  } else if (institutionType === "university" && department) {
    q = query(
      collection(db, "users"),
      where("institutionType", "==", "university"),
      where("department", "==", department),
      limit(20)
    );
  } else {
    q = query(collection(db, "users"), limit(20));
  }

  const snap = await getDocs(q);
  const users: PublicProfile[] = snap.docs
    .map((d) => {
      const data = d.data() as Record<string, unknown>;
      return {
        uid: d.id,
        name: (data.name as string) || "",
        avatar: (data.avatar as string) || "",
        institutionType: (data.institutionType as string) || "",
        className: (data.className as string) || "",
        department: (data.department as string) || "",
        university: (data.university as string) || "",
        schoolName: (data.schoolName as string) || "",
        bio: (data.bio as string) || "",
      };
    })
    .filter((u) => u.uid !== currentUserId);

  // Filter out already followed
  const followingSnap = await getDocs(
    query(collection(db, "connections"), where("followerId", "==", currentUserId))
  );
  const followingIds = new Set(followingSnap.docs.map((d) => d.data().followingId));

  return users.filter((u) => !followingIds.has(u.uid));
};
