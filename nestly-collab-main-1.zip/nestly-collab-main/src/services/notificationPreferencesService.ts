import { doc, setDoc, onSnapshot } from "firebase/firestore";
import { db } from "@/firebase/config";

export interface NotificationPreferences {
  likes: boolean;
  comments: boolean;
  follows: boolean;
  sessions: boolean;
  groupMessages: boolean;
  mutedUsers: string[];
  mutedGroups: string[];
}

export const defaultPreferences: NotificationPreferences = {
  likes: true,
  comments: true,
  follows: true,
  sessions: true,
  groupMessages: true,
  mutedUsers: [],
  mutedGroups: [],
};

// Get real-time preferences
export const subscribeToNotificationPreferences = (
  userId: string,
  callback: (prefs: NotificationPreferences) => void
) => {
  return onSnapshot(doc(db, "notification_preferences", userId), (snap) => {
    if (snap.exists()) {
      callback({ ...defaultPreferences, ...snap.data() } as NotificationPreferences);
    } else {
      callback(defaultPreferences);
    }
  });
};

// Update preferences
export const updateNotificationPreferences = async (
  userId: string,
  prefs: Partial<NotificationPreferences>
) => {
  await setDoc(doc(db, "notification_preferences", userId), prefs, { merge: true });
};
