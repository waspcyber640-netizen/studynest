import { useState, useEffect, useCallback, useRef } from "react";
import { syncTelegramFiles } from "@/services/telegramStorageService";
import { toast } from "sonner";

export type SyncStatus = "idle" | "syncing" | "success" | "error";

export interface SyncState {
  status: SyncStatus;
  lastSyncedAt: Date | null;
  lastResult: { removed: number; checked: number } | null;
  error: string | null;
  nextSyncIn: number; // seconds
}

const SYNC_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes
const COUNTDOWN_TICK_MS = 1000;

export const useTelegramAutoSync = (enabled = true) => {
  const [state, setState] = useState<SyncState>({
    status: "idle",
    lastSyncedAt: null,
    lastResult: null,
    error: null,
    nextSyncIn: SYNC_INTERVAL_MS / 1000,
  });

  const syncTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isMountedRef = useRef(true);

  const clearTimers = () => {
    if (syncTimerRef.current) clearInterval(syncTimerRef.current);
    if (countdownRef.current) clearInterval(countdownRef.current);
  };

  const startCountdown = useCallback(() => {
    if (countdownRef.current) clearInterval(countdownRef.current);

    let secondsLeft = SYNC_INTERVAL_MS / 1000;
    setState((prev) => ({ ...prev, nextSyncIn: secondsLeft }));

    countdownRef.current = setInterval(() => {
      secondsLeft -= 1;
      if (isMountedRef.current) {
        setState((prev) => ({ ...prev, nextSyncIn: Math.max(0, secondsLeft) }));
      }
      if (secondsLeft <= 0 && countdownRef.current) {
        clearInterval(countdownRef.current);
      }
    }, COUNTDOWN_TICK_MS);
  }, []);

  const runSync = useCallback(
    async (silent = false) => {
      if (!isMountedRef.current) return;

      setState((prev) => ({ ...prev, status: "syncing", error: null }));

      try {
        const result = await syncTelegramFiles();

        if (!isMountedRef.current) return;

        setState((prev) => ({
          ...prev,
          status: "success",
          lastSyncedAt: new Date(),
          lastResult: result,
          error: null,
        }));

        if (!silent) {
          if (result.removed > 0) {
            toast.success(`Sync complete — removed ${result.removed} stale file(s).`);
          } else {
            toast.success(`Sync complete — all ${result.checked} file(s) are valid.`);
          }
        } else if (result.removed > 0) {
          toast.info(`Auto-sync cleaned up ${result.removed} missing file(s).`);
        }
      } catch (err: any) {
        if (!isMountedRef.current) return;

        const message = err?.message || "Sync failed";
        setState((prev) => ({ ...prev, status: "error", error: message }));

        if (!silent) {
          toast.error(message);
        }
      } finally {
        if (isMountedRef.current) {
          startCountdown();
        }
      }
    },
    [startCountdown]
  );

  // Manual trigger (non-silent)
  const triggerSync = useCallback(() => {
    clearTimers();
    runSync(false);

    // Restart periodic sync timer after manual trigger
    syncTimerRef.current = setInterval(() => {
      runSync(true);
    }, SYNC_INTERVAL_MS);
  }, [runSync]);

  useEffect(() => {
    isMountedRef.current = true;

    if (!enabled) return;

    // Initial silent sync on mount
    runSync(true);

    // Set up periodic sync
    syncTimerRef.current = setInterval(() => {
      runSync(true);
    }, SYNC_INTERVAL_MS);

    return () => {
      isMountedRef.current = false;
      clearTimers();
    };
  }, [enabled, runSync]);

  const formatNextSync = () => {
    const s = state.nextSyncIn;
    if (s <= 0) return "syncing soon...";
    const m = Math.floor(s / 60);
    const sec = s % 60;
    if (m > 0) return `${m}m ${sec}s`;
    return `${sec}s`;
  };

  const formatLastSynced = () => {
    if (!state.lastSyncedAt) return null;
    const diff = Math.floor((Date.now() - state.lastSyncedAt.getTime()) / 1000);
    if (diff < 10) return "just now";
    if (diff < 60) return `${diff}s ago`;
    const m = Math.floor(diff / 60);
    return `${m}m ago`;
  };

  return {
    ...state,
    triggerSync,
    formatNextSync,
    formatLastSynced,
    isSyncing: state.status === "syncing",
  };
};
