import { useEffect } from "react";

interface PageMeta {
  title: string;
  description?: string;
  keywords?: string;
  image?: string;
  url?: string;
  type?: string;
  noindex?: boolean;
}

const usePageMeta = ({ title, description, keywords, image, url, type = "website", noindex = false }: PageMeta) => {
  useEffect(() => {
    const fullTitle = title === "StudyNest" ? "StudyNest — Student Collaboration Platform" : `${title} | StudyNest`;
    document.title = fullTitle;

    const setMeta = (selector: string, content: string, attr = "content") => {
      let meta = document.querySelector(selector) as HTMLMetaElement | null;
      if (meta) {
        meta.setAttribute(attr, content);
      } else {
        meta = document.createElement("meta");
        const [attrName, attrValue] = selector.replace(/[\[\]'"]/g, "").split("=");
        meta.setAttribute(attrName.replace("meta", "").trim(), attrValue);
        meta.setAttribute(attr, content);
        document.head.appendChild(meta);
      }
    };

    if (description) {
      setMeta('meta[name="description"]', description);
      setMeta('meta[property="og:description"]', description);
      setMeta('meta[name="twitter:description"]', description);
    }

    setMeta('meta[property="og:title"]', fullTitle);
    setMeta('meta[name="twitter:title"]', fullTitle);

    if (keywords) {
      setMeta('meta[name="keywords"]', keywords);
    }

    if (image) {
      setMeta('meta[property="og:image"]', image);
      setMeta('meta[name="twitter:image"]', image);
    }

    if (url) {
      setMeta('meta[property="og:url"]', url);
      const canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
      if (canonical) canonical.href = url;
    }

    setMeta('meta[property="og:type"]', type);

    // Handle noindex for private pages
    if (noindex) {
      setMeta('meta[name="robots"]', 'noindex, nofollow');
    } else {
      setMeta('meta[name="robots"]', 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1');
    }

  }, [title, description, keywords, image, url, type, noindex]);
};

export default usePageMeta;
