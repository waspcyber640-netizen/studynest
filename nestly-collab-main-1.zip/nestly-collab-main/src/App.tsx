import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import ErrorBoundary from "@/components/ErrorBoundary";
import Navbar from "@/components/Navbar";
import BottomNav from "@/components/BottomNav";
import Footer from "@/components/Footer";
import CookieConsent from "@/components/CookieConsent";
import ProtectedRoute from "@/components/ProtectedRoute";
import ScrollToTop from "@/components/ScrollToTop";

// Main pages
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import ForgotPassword from "./pages/ForgotPassword";
import Dashboard from "./pages/Dashboard";
import Assignments from "./pages/Assignments";
import Groups from "./pages/Groups";
import GroupChat from "./pages/GroupChat";
import Profile from "./pages/Profile";
import Notifications from "./pages/Notifications";
import TelegramFiles from "./pages/TelegramFiles";
import PeoplePage from "./pages/People";

// Legal pages
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";
import CookiePolicy from "./pages/CookiePolicy";
import CommunityGuidelines from "./pages/CommunityGuidelines";
import DMCAPolicy from "./pages/DMCAPolicy";

// Support pages
import HelpCenter from "./pages/HelpCenter";
import ContactUs from "./pages/ContactUs";
import ReportBug from "./pages/ReportBug";

// Informational pages
import AboutUs from "./pages/AboutUs";
import HowItWorks from "./pages/HowItWorks";
import FeaturesPage from "./pages/FeaturesPage";
import Changelog from "./pages/Changelog";
import Founder from "./pages/Founder";

// Error & system pages
import NotFound from "./pages/NotFound";
import ServerError from "./pages/ServerError";
import Maintenance from "./pages/Maintenance";
import AccountSuspended from "./pages/AccountSuspended";

// Account flow pages
import EmailVerification from "./pages/EmailVerification";
import Onboarding from "./pages/Onboarding";
import PasswordResetSuccess from "./pages/PasswordResetSuccess";
import AccountDeleted from "./pages/AccountDeleted";
import CompleteProfile from "./pages/CompleteProfile";
import EditProfile from "./pages/EditProfile";

const queryClient = new QueryClient();

const noBottomNavRoutes = ["/", "/login", "/signup", "/forgot-password", "/onboarding", "/complete-profile", "/verify-email", "/password-reset-success", "/account-deleted", "/suspended", "/maintenance", "/500"];

const AppContent = () => {
  const location = useLocation();
  const isChat = location.pathname.includes("/chat");
  const showBottomNav = !noBottomNavRoutes.includes(location.pathname) && !isChat;

  // Don't show footer on chat, error, or flow pages
  const noFooterRoutes = ["/onboarding", "/complete-profile", "/verify-email", "/password-reset-success", "/account-deleted", "/suspended", "/maintenance", "/500"];
  const showFooter = !isChat && !noFooterRoutes.includes(location.pathname);

  return (
    <>
      <Navbar />
      <Routes location={location} key={location.pathname}>
        {/* Public */}
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />

        {/* Protected app pages */}
        <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/assignments" element={<ProtectedRoute><Assignments /></ProtectedRoute>} />
        <Route path="/groups" element={<ProtectedRoute><Groups /></ProtectedRoute>} />
        <Route path="/groups/:id/chat" element={<ProtectedRoute><GroupChat /></ProtectedRoute>} />
        <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
        <Route path="/profile/edit" element={<ProtectedRoute><EditProfile /></ProtectedRoute>} />
        <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
        <Route path="/telegram-files" element={<ProtectedRoute><TelegramFiles /></ProtectedRoute>} />
        <Route path="/people" element={<ProtectedRoute><PeoplePage /></ProtectedRoute>} />

        {/* Legal */}
        <Route path="/privacy" element={<PrivacyPolicy />} />
        <Route path="/terms" element={<TermsOfService />} />
        <Route path="/cookies" element={<CookiePolicy />} />
        <Route path="/community-guidelines" element={<CommunityGuidelines />} />
        <Route path="/dmca" element={<DMCAPolicy />} />

        {/* Support */}
        <Route path="/help" element={<HelpCenter />} />
        <Route path="/contact" element={<ContactUs />} />
        <Route path="/report-bug" element={<ReportBug />} />

        {/* Informational */}
        <Route path="/about" element={<AboutUs />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/features" element={<FeaturesPage />} />
        <Route path="/changelog" element={<Changelog />} />
        <Route path="/founder" element={<Founder />} />

        {/* Error & System */}
        <Route path="/500" element={<ServerError />} />
        <Route path="/maintenance" element={<Maintenance />} />
        <Route path="/suspended" element={<AccountSuspended />} />

        {/* Account Flow */}
        <Route path="/verify-email" element={<EmailVerification />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/password-reset-success" element={<PasswordResetSuccess />} />
        <Route path="/account-deleted" element={<AccountDeleted />} />
        <Route path="/complete-profile" element={<CompleteProfile />} />

        <Route path="*" element={<NotFound />} />
      </Routes>
      {showBottomNav && <BottomNav />}
      {showFooter && <Footer />}
      <CookieConsent />
    </>
  );
};

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <ScrollToTop />
          <AuthProvider>
            <AppContent />
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

export default App;
