import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, Loader2 } from "lucide-react";
import { reportContent } from "@/services/safetyService";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reportedUserId: string;
  contentId?: string;
  contentType: "assignment" | "comment" | "group" | "user" | "session";
}

const reasons = [
  "Spam or misleading",
  "Inappropriate content",
  "Harassment or bullying",
  "Copyright violation",
  "Other",
];

const ReportModal = ({ open, onOpenChange, reportedUserId, contentId, contentType }: Props) => {
  const { user } = useAuth();
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!user || !reason) {
      toast.error("Please select a reason.");
      return;
    }
    setSubmitting(true);
    try {
      await reportContent({
        reporterId: user.uid,
        reportedUserId,
        contentId,
        contentType,
        reason,
        details,
      });
      toast.success("Report submitted. We'll review it shortly.");
      onOpenChange(false);
      setReason("");
      setDetails("");
    } catch (err: any) {
      toast.error(err.message || "Failed to submit report");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass border-border/50 sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            Report {contentType}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Reason *</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger className="mt-1.5 bg-secondary/50 border-border/50">
                <SelectValue placeholder="Select a reason" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                {reasons.map((r) => (
                  <SelectItem key={r} value={r}>{r}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Additional details</Label>
            <Textarea
              placeholder="Provide more context..."
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              className="mt-1.5 bg-secondary/50 border-border/50 min-h-[80px]"
            />
          </div>
          <Button onClick={handleSubmit} disabled={submitting || !reason} className="w-full">
            {submitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
            Submit Report
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ReportModal;
