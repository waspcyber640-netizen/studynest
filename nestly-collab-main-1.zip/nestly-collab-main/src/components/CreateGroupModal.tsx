import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Loader2 } from "lucide-react";
import { subjects } from "@/data/mock";
import { useAuth } from "@/context/AuthContext";
import { createGroup } from "@/services/groupService";
import { useState } from "react";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const CreateGroupModal = ({ open, onOpenChange }: Props) => {
  const { user, profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: "", subject: "", customSubject: "", description: "", isPublic: true });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || (!form.subject)) {
      toast.error("Please fill in group name and subject.");
      return;
    }
    if (form.subject === "Custom" && !form.customSubject.trim()) {
      toast.error("Please enter a custom subject name.");
      return;
    }
    if (!user) {
      toast.error("You must be logged in.");
      return;
    }
    setLoading(true);
    try {
      const finalSubject = form.subject === "Custom" ? form.customSubject.trim() : form.subject;
      await createGroup({
        name: form.name,
        subject: finalSubject,
        description: form.description,
        isPublic: form.isPublic,
        creatorId: user.uid,
        creatorName: profile?.name || user.displayName || "Student",
      });
      toast.success("Group created! 🎉");
      setForm({ name: "", subject: "", customSubject: "", description: "", isPublic: true });
      onOpenChange(false);
    } catch (err: any) {
      toast.error(err.message || "Failed to create group.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass border-border/50 sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Create Study Group</DialogTitle>
        </DialogHeader>
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div>
            <Label htmlFor="gname">Group Name *</Label>
            <Input
              id="gname"
              placeholder="e.g. Algebra Aces"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className="mt-1.5 bg-secondary/50 border-border/50"
            />
          </div>
          <div>
            <Label>Subject *</Label>
            <Select value={form.subject} onValueChange={(v) => setForm((f) => ({ ...f, subject: v }))}>
              <SelectTrigger className="mt-1.5 bg-secondary/50 border-border/50">
                <SelectValue placeholder="Select subject" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                {subjects.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {form.subject === "Custom" && (
            <div>
              <Label htmlFor="customSubject">Custom Subject Name *</Label>
              <Input
                id="customSubject"
                placeholder="e.g. Data Structures, Economics"
                value={form.customSubject}
                onChange={(e) => setForm((f) => ({ ...f, customSubject: e.target.value }))}
                className="mt-1.5 bg-secondary/50 border-border/50"
              />
            </div>
          )}
          <div>
            <Label htmlFor="gdesc">Description</Label>
            <Textarea
              id="gdesc"
              placeholder="What's this group about?"
              value={form.description}
              onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              className="mt-1.5 bg-secondary/50 border-border/50 min-h-[80px]"
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="public">Public Group</Label>
            <Switch
              id="public"
              checked={form.isPublic}
              onCheckedChange={(v) => setForm((f) => ({ ...f, isPublic: v }))}
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Group
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateGroupModal;
