import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, Send, Loader2 } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { subscribeToComments, addComment, Comment } from "@/services/assignmentService";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

interface Props {
  assignmentId: string;
  commentCount: number;
}

const CommentsSection = ({ assignmentId, commentCount }: Props) => {
  const { user, profile } = useAuth();
  const [open, setOpen] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!open) return;
    const unsub = subscribeToComments(assignmentId, setComments);
    return unsub;
  }, [assignmentId, open]);

  const handleSend = async () => {
    if (!text.trim() || !user) return;
    setSending(true);
    try {
      const displayName = profile?.name || user.displayName || "Student";
      const initials = displayName.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
      await addComment(assignmentId, {
        userId: user.uid,
        userName: displayName,
        userAvatar: initials,
        text: text.trim(),
      });
      setText("");
    } catch (err: any) {
      toast.error("Failed to post comment.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="w-full">
      <Button
        variant="ghost"
        size="sm"
        className="h-8 text-xs gap-1.5"
        onClick={() => setOpen(!open)}
      >
        <MessageCircle className="h-3.5 w-3.5" />
        {commentCount || 0}
      </Button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="pt-3 space-y-2 max-h-48 overflow-y-auto">
              {comments.length === 0 && (
                <p className="text-xs text-muted-foreground text-center py-3">
                  No comments yet. Be the first!
                </p>
              )}
              {comments.map((c) => (
                <div key={c.id} className="flex items-start gap-2">
                  <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-[9px] font-semibold text-primary shrink-0">
                    {c.userAvatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline gap-2">
                      <span className="text-xs font-medium">{c.userName}</span>
                      {c.createdAt && (
                        <span className="text-[10px] text-muted-foreground">
                          {formatDistanceToNow(c.createdAt.toDate(), { addSuffix: true })}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{c.text}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2 pt-2">
              <Input
                placeholder="Write a comment..."
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                className="h-8 text-xs bg-secondary/50 border-border/50"
              />
              <Button
                size="sm"
                className="h-8 px-3"
                onClick={handleSend}
                disabled={sending || !text.trim()}
              >
                {sending ? <Loader2 className="h-3 w-3 animate-spin" /> : <Send className="h-3 w-3" />}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CommentsSection;
