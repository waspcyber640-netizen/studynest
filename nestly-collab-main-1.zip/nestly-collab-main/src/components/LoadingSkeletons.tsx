import { cn } from "@/lib/utils";

interface SkeletonCardProps {
  className?: string;
}

export const SkeletonCard = ({ className }: SkeletonCardProps) => (
  <div className={cn("glass rounded-xl p-4 sm:p-5 animate-pulse", className)}>
    <div className="flex items-start gap-3 mb-3">
      <div className="h-10 w-10 rounded-lg bg-muted/50 shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="h-4 bg-muted/50 rounded w-3/4" />
        <div className="flex gap-2">
          <div className="h-4 bg-muted/50 rounded w-16" />
          <div className="h-4 bg-muted/50 rounded w-10" />
        </div>
      </div>
    </div>
    <div className="h-3 bg-muted/50 rounded w-full mb-2" />
    <div className="h-3 bg-muted/50 rounded w-2/3" />
  </div>
);

export const SkeletonLine = ({ className }: SkeletonCardProps) => (
  <div className={cn("glass rounded-xl p-4 animate-pulse flex items-center gap-3", className)}>
    <div className="h-10 w-10 rounded-lg bg-muted/50 shrink-0" />
    <div className="flex-1 space-y-1.5">
      <div className="h-4 bg-muted/50 rounded w-1/2" />
      <div className="h-3 bg-muted/50 rounded w-1/3" />
    </div>
    <div className="h-8 w-20 bg-muted/50 rounded shrink-0" />
  </div>
);

export const SkeletonGrid = ({ count = 6 }: { count?: number }) => (
  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
    {Array.from({ length: count }).map((_, i) => (
      <SkeletonCard key={i} />
    ))}
  </div>
);

export const SkeletonList = ({ count = 4 }: { count?: number }) => (
  <div className="space-y-3">
    {Array.from({ length: count }).map((_, i) => (
      <SkeletonLine key={i} />
    ))}
  </div>
);
