import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useAuth } from "@/context/AuthContext";
import { useState, useEffect } from "react";
import {
  subscribeToNotifications,
  markNotificationRead,
  AppNotification,
} from "@/services/groupService";
import { formatDistanceToNow } from "date-fns";

const NotificationBell = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  useEffect(() => {
    if (!user) return;
    const unsub = subscribeToNotifications(user.uid, setNotifications);
    return unsub;
  }, [user]);

  const unread = notifications.filter((n) => !n.read).length;

  const handleRead = async (id: string) => {
    try {
      await markNotificationRead(id);
    } catch {
      // silently fail if Firestore rules block
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative h-8 w-8">
          <Bell size={16} />
          {unread > 0 && (
            <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-primary text-[10px] font-bold text-primary-foreground flex items-center justify-center">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0 glass border-border/50" align="end">
        <div className="p-3 border-b border-border/30">
          <h3 className="font-semibold text-sm">Notifications</h3>
        </div>
        <div className="max-h-64 overflow-auto">
          {notifications.length === 0 ? (
            <p className="p-4 text-sm text-muted-foreground text-center">No notifications yet.</p>
          ) : (
            notifications.slice(0, 10).map((n) => {
              const timeAgo = n.createdAt
                ? formatDistanceToNow(n.createdAt.toDate(), { addSuffix: true })
                : "just now";
              return (
                <button
                  key={n.id}
                  onClick={() => handleRead(n.id)}
                  className={`w-full text-left p-3 border-b border-border/20 hover:bg-secondary/30 transition-colors ${
                    !n.read ? "bg-primary/5" : ""
                  }`}
                >
                  <p className="text-sm font-medium">{n.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{n.body}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">{timeAgo}</p>
                </button>
              );
            })
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default NotificationBell;
