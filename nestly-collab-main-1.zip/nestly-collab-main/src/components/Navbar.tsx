import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X, LogOut } from "lucide-react";
import NotificationBell from "@/components/NotificationBell";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, profile, logOut } = useAuth();
  const isLanding = location.pathname === "/";
  const isAuth = ["/login", "/signup", "/forgot-password"].includes(location.pathname);

  const handleLogout = async () => {
    await logOut();
    toast.success("Logged out.");
    navigate("/");
  };

  const initials = profile?.name
    ? profile.name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2)
    : user?.displayName
      ? user.displayName.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2)
      : "U";

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/30">
      <div className="container mx-auto px-4 h-14 flex items-center justify-between">
        <Link to={user ? "/dashboard" : "/"} className="flex items-center gap-2 group">
          <img src="/favicon.png" alt="StudyNest" className="h-8 w-8 rounded-lg object-contain" />
          <span className="text-lg font-bold gradient-text">StudyNest</span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-5">
          {user && !isLanding && !isAuth && (
            <>
              <Link to="/dashboard" className={`text-sm transition-colors ${location.pathname === "/dashboard" ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"}`}>Dashboard</Link>
              <Link to="/assignments" className={`text-sm transition-colors ${location.pathname === "/assignments" ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"}`}>Feed</Link>
              
              <Link to="/groups" className={`text-sm transition-colors ${location.pathname.startsWith("/groups") ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"}`}>Groups</Link>
              <Link to="/people" className={`text-sm transition-colors ${location.pathname === "/people" ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"}`}>People</Link>
              <Link to="/profile" className={`text-sm transition-colors ${location.pathname === "/profile" ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"}`}>Profile</Link>
            </>
          )}
          {user ? (
            <div className="flex items-center gap-2">
              <NotificationBell />
              <Link to="/profile" className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary hover:bg-primary/30 transition-colors">
                {initials}
              </Link>
              <Button variant="ghost" size="sm" onClick={handleLogout} className="text-muted-foreground">
                <LogOut size={16} />
              </Button>
            </div>
          ) : (isLanding || isAuth) ? (
            <div className="flex gap-3">
              <Button variant="ghost" size="sm" asChild><Link to="/login">Log In</Link></Button>
              <Button size="sm" asChild><Link to="/signup">Sign Up</Link></Button>
            </div>
          ) : null}
        </div>

        {/* Mobile toggle */}
        <div className="md:hidden flex items-center gap-2">
          {user && <NotificationBell />}
          <button className="text-foreground" onClick={() => setOpen(!open)}>
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden glass border-t border-border/30 overflow-hidden"
          >
            <div className="p-4 flex flex-col gap-3">
              {user ? (
                <>
                  <Link to="/dashboard" onClick={() => setOpen(false)} className="text-sm text-muted-foreground">Dashboard</Link>
                  <Link to="/assignments" onClick={() => setOpen(false)} className="text-sm text-muted-foreground">Feed</Link>
                  
                  <Link to="/groups" onClick={() => setOpen(false)} className="text-sm text-muted-foreground">Groups</Link>
                  <Link to="/people" onClick={() => setOpen(false)} className="text-sm text-muted-foreground">People</Link>
                  <Link to="/profile" onClick={() => setOpen(false)} className="text-sm text-muted-foreground">Profile</Link>
                  <Button variant="ghost" size="sm" onClick={() => { handleLogout(); setOpen(false); }} className="justify-start text-muted-foreground">
                    <LogOut size={16} className="mr-2" /> Log Out
                  </Button>
                </>
              ) : (
                <div className="flex gap-3">
                  <Button variant="ghost" asChild className="flex-1"><Link to="/login" onClick={() => setOpen(false)}>Log In</Link></Button>
                  <Button asChild className="flex-1"><Link to="/signup" onClick={() => setOpen(false)}>Sign Up</Link></Button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
