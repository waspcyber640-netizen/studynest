import { useMemo } from "react";
import { Check, X } from "lucide-react";

interface PasswordStrengthProps {
  password: string;
}

interface Requirement {
  label: string;
  test: (pw: string) => boolean;
}

const requirements: Requirement[] = [
  { label: "At least 8 characters", test: (pw) => pw.length >= 8 },
  { label: "One uppercase letter", test: (pw) => /[A-Z]/.test(pw) },
  { label: "One lowercase letter", test: (pw) => /[a-z]/.test(pw) },
  { label: "One number", test: (pw) => /[0-9]/.test(pw) },
  { label: "One special character (!@#$%^&*)", test: (pw) => /[!@#$%^&*(),.?":{}|<>]/.test(pw) },
];

export const getPasswordStrength = (password: string): { score: number; label: string; color: string } => {
  const passed = requirements.filter((r) => r.test(password)).length;
  
  if (passed === 0) return { score: 0, label: "", color: "" };
  if (passed <= 2) return { score: 1, label: "Weak", color: "bg-destructive" };
  if (passed <= 3) return { score: 2, label: "Fair", color: "bg-yellow-500" };
  if (passed <= 4) return { score: 3, label: "Good", color: "bg-primary" };
  return { score: 4, label: "Strong", color: "bg-green-500" };
};

export const isPasswordStrong = (password: string): boolean => {
  return requirements.every((r) => r.test(password));
};

const PasswordStrength = ({ password }: PasswordStrengthProps) => {
  const strength = useMemo(() => getPasswordStrength(password), [password]);
  const passedRequirements = useMemo(
    () => requirements.map((r) => ({ ...r, passed: r.test(password) })),
    [password]
  );

  if (!password) return null;

  return (
    <div className="space-y-2 mt-2">
      {/* Strength bar */}
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden flex gap-0.5">
          {[1, 2, 3, 4].map((level) => (
            <div
              key={level}
              className={`flex-1 rounded-full transition-colors ${
                level <= strength.score ? strength.color : "bg-secondary"
              }`}
            />
          ))}
        </div>
        {strength.label && (
          <span className={`text-xs font-medium ${
            strength.score === 1 ? "text-destructive" :
            strength.score === 2 ? "text-yellow-500" :
            strength.score === 3 ? "text-primary" :
            "text-green-500"
          }`}>
            {strength.label}
          </span>
        )}
      </div>

      {/* Requirements list */}
      <div className="grid grid-cols-1 gap-1">
        {passedRequirements.map((req) => (
          <div key={req.label} className="flex items-center gap-1.5">
            {req.passed ? (
              <Check className="h-3 w-3 text-green-500" />
            ) : (
              <X className="h-3 w-3 text-muted-foreground" />
            )}
            <span className={`text-[11px] ${req.passed ? "text-muted-foreground" : "text-muted-foreground/70"}`}>
              {req.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PasswordStrength;
