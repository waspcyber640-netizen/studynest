import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { UserPlus, UserMinus, Loader2 } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import {
  followUser,
  unfollowUser,
  subscribeToFollowStatus,
} from "@/services/connectionService";
import { toast } from "sonner";

interface Props {
  targetUserId: string;
  targetUserName?: string;
  size?: "sm" | "default";
}

const FollowButton = ({ targetUserId, targetUserName, size = "sm" }: Props) => {
  const { user } = useAuth();
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user || user.uid === targetUserId) return;
    const unsub = subscribeToFollowStatus(user.uid, targetUserId, setIsFollowing);
    return unsub;
  }, [user, targetUserId]);

  if (!user || user.uid === targetUserId) return null;

  const handleToggle = async () => {
    setLoading(true);
    try {
      if (isFollowing) {
        await unfollowUser(user.uid, targetUserId);
        toast.success("Unfollowed");
      } else {
        await followUser(user.uid, targetUserId);
        toast.success(`Following ${targetUserName || "user"}!`);
      }
    } catch (err: any) {
      toast.error(err.message || "Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      variant={isFollowing ? "outline" : "default"}
      size={size}
      onClick={handleToggle}
      disabled={loading}
      className="text-xs"
    >
      {loading ? (
        <Loader2 className="h-3 w-3 animate-spin mr-1" />
      ) : isFollowing ? (
        <UserMinus className="h-3 w-3 mr-1" />
      ) : (
        <UserPlus className="h-3 w-3 mr-1" />
      )}
      {isFollowing ? "Unfollow" : "Follow"}
    </Button>
  );
};

export default FollowButton;
