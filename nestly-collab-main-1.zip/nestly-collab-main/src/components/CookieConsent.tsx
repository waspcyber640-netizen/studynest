import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Cookie, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const CookieConsent = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const accept = () => {
    localStorage.setItem("cookie-consent", "accepted");
    setVisible(false);
  };

  const manage = () => {
    localStorage.setItem("cookie-consent", "managed");
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 z-[60] p-3 sm:p-4"
        >
          <div className="container mx-auto max-w-2xl">
            <div className="glass rounded-xl p-4 sm:p-5 border border-border/50 shadow-2xl">
              <div className="flex items-start gap-3">
                <Cookie className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium mb-1">We use cookies 🍪</p>
                  <p className="text-xs text-muted-foreground mb-3">
                    We use cookies to improve your experience. By continuing, you agree to our{" "}
                    <Link to="/cookies" className="text-primary hover:underline">Cookie Policy</Link>.
                  </p>
                  <div className="flex gap-2">
                    <Button size="sm" className="h-8 text-xs" onClick={accept}>Accept All</Button>
                    <Button size="sm" variant="outline" className="h-8 text-xs" onClick={manage}>Manage Preferences</Button>
                  </div>
                </div>
                <button onClick={() => setVisible(false)} className="text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieConsent;
