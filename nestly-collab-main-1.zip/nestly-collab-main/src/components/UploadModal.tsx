import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, FileUp, X, File } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useState, useRef } from "react";
import { subjects } from "@/data/mock";
import { useAuth } from "@/context/AuthContext";
import { uploadFile, createAssignment } from "@/services/assignmentService";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  groupId?: string;
  groupName?: string;
}

const UploadModal = ({ open, onOpenChange, groupId, groupName }: Props) => {
  const { user, profile } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState("");

  const reset = () => {
    setFile(null);
    setTitle("");
    setSubject("");
    setDescription("");
    setTags("");
    setProgress(0);
    setUploading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || !title || !subject || !user) {
      toast.error("Please fill in title, subject, and select a file.");
      return;
    }

    setUploading(true);
    try {
      const { url, fileName, fileType, fileSize } = await uploadFile(file, setProgress);
      const displayName = profile?.name || user.displayName || "Student";
      const initials = displayName.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);

      await createAssignment({
        title,
        description,
        subject,
        tags: tags.split(",").map((t) => t.trim()).filter(Boolean),
        fileUrl: url,
        fileName,
        fileType,
        fileSize,
        uploaderId: user.uid,
        uploaderName: displayName,
        uploaderAvatar: initials,
        institutionType: profile?.institutionType || "",
        className: profile?.className || "",
        department: profile?.department || "",
        university: profile?.university || "",
        schoolName: profile?.schoolName || "",
        groupId: groupId || undefined,
        groupName: groupName || undefined,
      });

      toast.success("Assignment uploaded! 🎉");
      reset();
      onOpenChange(false);
    } catch (err: any) {
      toast.error(err.message || "Upload failed.");
      setUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const dropped = e.dataTransfer.files[0];
    if (dropped) setFile(dropped);
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!uploading) { onOpenChange(v); if (!v) reset(); } }}>
      <DialogContent className="glass border-border/50 sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Upload Assignment</DialogTitle>
        </DialogHeader>
        <form className="space-y-4" onSubmit={handleSubmit}>
          <input ref={fileRef} type="file" accept=".pdf,.docx,.pptx,.xlsx,.txt,.ipynb,.zip" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          {!file ? (
            <div onClick={() => fileRef.current?.click()} onDrop={handleDrop} onDragOver={(e) => e.preventDefault()} className="border-2 border-dashed border-border/50 rounded-xl p-6 sm:p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
              <FileUp className="h-8 w-8 sm:h-10 sm:w-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">Drag & drop your file here, or <span className="text-primary">browse</span></p>
              <p className="text-xs text-muted-foreground mt-1">PDF, DOCX, PPTX, XLSX up to 25MB</p>
            </div>
          ) : (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 border border-border/30 overflow-hidden">
              <File className="h-8 w-8 text-primary shrink-0" />
              <div className="flex-1 min-w-0 overflow-hidden">
                <p className="text-sm font-medium truncate max-w-full">{file.name}</p>
                <p className="text-xs text-muted-foreground">{formatSize(file.size)}</p>
              </div>
              <Button type="button" variant="ghost" size="sm" onClick={() => setFile(null)} disabled={uploading}><X className="h-4 w-4" /></Button>
            </div>
          )}

          <div>
            <Label htmlFor="title">Title *</Label>
            <Input id="title" placeholder="e.g. Linear Algebra Problem Set 4" value={title} onChange={(e) => setTitle(e.target.value)} className="mt-1.5 bg-secondary/50 border-border/50" disabled={uploading} />
          </div>
          <div>
            <Label>Subject *</Label>
            <Select value={subject} onValueChange={setSubject} disabled={uploading}>
              <SelectTrigger className="mt-1.5 bg-secondary/50 border-border/50"><SelectValue placeholder="Select subject" /></SelectTrigger>
              <SelectContent className="bg-card border-border">
                {subjects.map((s) => (<SelectItem key={s} value={s}>{s}</SelectItem>))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="desc">Description</Label>
            <Textarea id="desc" placeholder="Brief description..." value={description} onChange={(e) => setDescription(e.target.value)} className="mt-1.5 bg-secondary/50 border-border/50 min-h-[80px]" disabled={uploading} />
          </div>
          <div>
            <Label htmlFor="tags">Tags</Label>
            <Input id="tags" placeholder="e.g. midterm, chapter-5, practice" value={tags} onChange={(e) => setTags(e.target.value)} className="mt-1.5 bg-secondary/50 border-border/50" disabled={uploading} />
          </div>

          {/* Auto-targeting info */}
          {profile?.institutionType && (
            <div className="rounded-lg bg-primary/5 border border-primary/20 p-3">
              <p className="text-xs text-muted-foreground">
                📌 This assignment will be visible to{" "}
                {profile.institutionType === "school"
                  ? `Class ${profile.className} students`
                  : `${profile.department} students at ${profile.university}`}
              </p>
            </div>
          )}

          {uploading && (
            <div className="space-y-2">
              <Progress value={Math.min(progress, 100)} className="h-2" />
              <p className="text-xs text-muted-foreground text-center">{Math.min(Math.round(progress), 100)}% uploaded</p>
            </div>
          )}

          <Button type="submit" className="w-full" disabled={uploading || !file}>
            <Upload className="mr-2 h-4 w-4" />{uploading ? "Uploading..." : "Upload"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default UploadModal;
