import { Link, useLocation } from "react-router-dom";
import { Home, FileText, Users, UserPlus, User } from "lucide-react";
import { motion } from "framer-motion";

const tabs = [
  { icon: Home, label: "Home", to: "/dashboard" },
  { icon: FileText, label: "Feed", to: "/assignments" },
  { icon: Users, label: "Groups", to: "/groups" },
  { icon: UserPlus, label: "People", to: "/people" },
  { icon: User, label: "Profile", to: "/profile" },
];

const BottomNav = () => {
  const { pathname } = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 glass border-t border-border/30 md:hidden">
      <div className="flex items-center justify-around h-16 px-2">
        {tabs.map((tab) => {
          const active =
            pathname === tab.to ||
            (tab.to === "/groups" && pathname.startsWith("/groups"));
          return (
            <Link
              key={tab.label}
              to={tab.to}
              className={`relative flex flex-col items-center justify-center gap-0.5 min-w-[44px] min-h-[44px] rounded-xl transition-colors ${
                active ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <tab.icon size={20} />
              <span className="text-[10px] font-medium">{tab.label}</span>
              {active && (
                <motion.div
                  layoutId="bottomnav-indicator"
                  className="absolute -bottom-1 h-1 w-6 rounded-full bg-primary"
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
